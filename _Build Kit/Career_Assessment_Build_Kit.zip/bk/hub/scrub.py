"""Remove DVR / VR agency references from assessment text.
Rule (Shari, Sept 27 2026): no DVR or VR on anything. Use "career counselor".
Usage: python3 scrub.py file1.html file2.py ...   (edits in place, prints counts)
Also importable: from scrub import scrub_text
"""
import re, sys
REPL = [
    (r'Ask your VR counselor or Job Service North Dakota if WIOA or VR can help',
     'Ask a career counselor or Job Service North Dakota if WIOA or other programs can help'),
    (r'\bVR counselor\b', 'career counselor'),
    (r'\bVR Counselor\b', 'Career Counselor'),
    (r'\s*[—–-]\s*North Dakota Division of Vocational Rehabilitation', ' — North Dakota'),
    (r'North Dakota Division of Vocational Rehabilitation', 'North Dakota'),
    (r'\s*[—–-]\s*ND D?VR\b', ''),
    (r'\bvocational rehabilitation office\b', 'local Job Service North Dakota office'),
    (r'\bVocational Rehabilitation office\b', 'local Job Service North Dakota office'),
    (r'\bND DVR\b', 'North Dakota'),
]
CHECK = re.compile(r'\b(DVR|VR)\b|Vocational Rehabilitation|vocational rehabilitation')
def scrub_text(s):
    n = 0
    for a, b in REPL:
        s, k = re.subn(a, b, s); n += k
    return s, n
def leftovers(s):
    s = re.sub(r'data:[^"\')\s]+', '', s)   # ignore embedded images
    return [m.group(0) for m in CHECK.finditer(s)]
if __name__ == '__main__':
    for f in sys.argv[1:]:
        s = open(f, encoding='utf-8').read()
        s2, n = scrub_text(s)
        if n: open(f, 'w', encoding='utf-8').write(s2)
        left = leftovers(s2)
        print(f'{f}: {n} replaced, {len(left)} left {left[:5]}')
