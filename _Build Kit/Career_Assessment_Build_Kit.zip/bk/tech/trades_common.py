from careers_data import W
VR_TIP = ('Start with financial aid, scholarships, and any help an employer offers \u2014 that is where the money starts. '
          'After that, ask a career counselor or Job Service North Dakota whether WIOA or other programs can help with what is left over, like '
          'training, tools, work boots, or exam fees. What can be paid for depends on the program and on your own situation, so ask before you '
          'sign up rather than after. Registered apprenticeships let you earn a paycheck while you learn \u2014 see '
          'jobsnd.com/job-seeker/apprenticeships for ND programs.')

ENG_TIP = ('Start with financial aid and scholarships. Fill out the FAFSA, ask the school\u2019s financial aid office what you qualify for, '
           'and ask an employer whether they help pay for school. That is where the money starts. '
           'After that, ask a career counselor or Job Service North Dakota whether WIOA or other programs can help with what is left over, like '
           'tuition, books, a laptop, or exam fees. What can be paid for depends on the program and on your own situation, so ask before you '
           'enroll rather than after. Worth asking about specifically: two-year degrees that train you for a job, like civil engineering '
           'technology, land surveying, mechatronics, electronics, or instrumentation. North Dakota two-year colleges also cost far less than '
           'a university. Ask about paid summer internships too \u2014 engineering firms, plants, and survey crews hire students while they are '
           'still in school.')

def recs(job, start, alt):
    return [f'You are an excellent fit for {job}. You have the drive and the readiness. Pursue this.',
            f'{job[0].upper() + job[1:]} is a strong option. {start}',
            f'You could do well here. Job shadow or talk to someone in {job} first to see if the day-to-day work fits you.',
            f'This might work, but look at related trades too, like {alt}.',
            'This does not seem like your best fit right now. Explore other career areas.']

def mot(q1, q2, q3):
    return [('love', q1, 9), ('hands', q2, 9), ('path', q3, 8),
            ('salary', 'The pay and job security appeal to me.', 6),
            ('recommend', 'Someone suggested it to me.', 4),
            ('explore', 'I am still exploring my options.', 3)]

def fut(a, b, c):
    return [('a', a), ('b', b), ('c', c), ('research', 'Research programs and costs first.'), ('undecided', 'Still deciding.')]

def imgs(what, day, training, paths):
    return {'what': what, 'day': day, 'training': training, 'paths': paths}
