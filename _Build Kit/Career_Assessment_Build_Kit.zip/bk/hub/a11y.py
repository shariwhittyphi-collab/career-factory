"""Add reader accessibility controls to a career assessment page.
Adds: skip link, text-size buttons (Normal/Large/Extra Large), light/dark toggle,
reduced-motion support. Choices remembered per browser (localStorage, try/catch).
Usage: python3 a11y.py file1.html file2.html ...   (edits in place)
Importable: from a11y import add_a11y
"""
import re, sys

CSS = """
        /* ---- Reader accessibility controls ---- */
        .skip-link { position: absolute; left: -9999px; top: 0; z-index: 100;
            background: var(--accent-blue); color: #fff; padding: 0.75rem 1.25rem;
            border-radius: 0 0 6px 0; font-weight: 700; text-decoration: none; }
        .skip-link:focus { left: 0; }
        .a11y-bar { display: flex; flex-wrap: wrap; align-items: center; gap: 0.5rem;
            margin-bottom: 1rem; padding: 0.6rem 0.75rem; background: var(--header-bg);
            border: 1px solid var(--border-color); border-radius: 8px; }
        .a11y-bar .a11y-label { font-size: 0.9rem; font-weight: 600; color: var(--text-light); margin-right: 0.25rem; }
        .a11y-bar button { width: auto !important; flex: 0 0 auto; min-height: 44px; min-width: 44px; padding: 0.4rem 0.8rem; cursor: pointer; font-size: 0.95rem;
            background: var(--primary-bg); color: var(--text-dark); border: 2px solid var(--border-color);
            border-radius: 6px; font-family: inherit; font-weight: 600; }
        .a11y-bar button:hover { border-color: var(--accent-blue); }
        .a11y-bar button[aria-pressed="true"] { background: var(--accent-blue); color: #fff; border-color: var(--accent-blue); }
        .a11y-bar button:focus-visible { outline: 3px solid var(--accent-blue); outline-offset: 2px; }
        .a11y-bar .a11y-gap { flex: 1 1 0; min-width: 0; }
        .a11y-bar .a11y-label { flex: 0 0 auto; }
        body.text-large { font-size: 1.15rem; }
        body.text-xl { font-size: 1.35rem; }
        body.text-large .subtitle, body.text-xl .subtitle { font-size: 1.05em; }
        @media print { .a11y-bar, .skip-link { display: none !important; } }
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after { animation-duration: 0.01ms !important; animation-iteration-count: 1 !important;
                transition-duration: 0.01ms !important; scroll-behavior: auto !important; }
        }
"""

DARK_OVERRIDE = """
        html[data-theme="dark"] {
            --primary-bg: #1a1a1a; --header-bg: #2d2d2d; --accent-light: #003d99;
            --text-dark: #e0e0e0; --text-light: #b0b0b0; --border-color: #444444;
            --light-gray: #333333; --accent-blue: #6cb4ff; color-scheme: dark;
        }
        html[data-theme="light"] {
            --primary-bg: #f8f9fa; --header-bg: #ffffff; --accent-light: #e6f2ff;
            --text-dark: #1a1a1a; --text-light: #666666; --border-color: #dddddd;
            --light-gray: #f5f5f5; --accent-blue: #0066cc; color-scheme: light;
        }
"""

BAR = """<a class="skip-link" href="#main-content">Skip to main content</a>
    <div class="container">
        <div class="a11y-bar" role="group" aria-label="Display settings">
            <span class="a11y-label">Text size</span>
            <button type="button" id="sizeNormal" onclick="setTextSize('normal')" aria-pressed="true">Normal</button>
            <button type="button" id="sizeLarge" onclick="setTextSize('large')" aria-pressed="false">Large</button>
            <button type="button" id="sizeXL" onclick="setTextSize('xl')" aria-pressed="false">Largest</button>
            <span class="a11y-gap"></span>
            <button type="button" id="themeBtn" onclick="toggleTheme()" aria-pressed="false">&#9790; Dark mode</button>
        </div>
"""

JS = """
        // ---- Reader accessibility controls ----
        function a11yGet(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
        function a11ySet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
        function setTextSize(size) {
            document.body.classList.remove('text-large', 'text-xl');
            if (size === 'large') document.body.classList.add('text-large');
            if (size === 'xl') document.body.classList.add('text-xl');
            var ids = { normal: 'sizeNormal', large: 'sizeLarge', xl: 'sizeXL' };
            for (var k in ids) {
                var b = document.getElementById(ids[k]);
                if (b) b.setAttribute('aria-pressed', String(k === size));
            }
            a11ySet('textSize', size);
        }
        function applyTheme(mode) {
            var btn = document.getElementById('themeBtn');
            if (mode === 'dark') {
                document.documentElement.setAttribute('data-theme', 'dark');
                if (btn) { btn.innerHTML = '\\u2600 Light mode'; btn.setAttribute('aria-pressed', 'true'); }
            } else {
                document.documentElement.setAttribute('data-theme', 'light');
                if (btn) { btn.innerHTML = '\\u263D Dark mode'; btn.setAttribute('aria-pressed', 'false'); }
            }
            a11ySet('theme', mode);
        }
        function toggleTheme() {
            var now = document.documentElement.getAttribute('data-theme');
            applyTheme(now === 'dark' ? 'light' : 'dark');
        }
        (function () {
            var t = a11yGet('theme');
            if (t === 'dark' || t === 'light') applyTheme(t);
            var s = a11yGet('textSize');
            if (s === 'large' || s === 'xl') setTextSize(s);
        })();
"""

def add_a11y(s):
    if 'a11y-bar' in s:
        return s, 'already'
    # CSS: append inside the existing <style>
    s = s.replace('</style>', CSS + DARK_OVERRIDE + '    </style>', 1)
    # Bar: replace the opening container div
    if '<body>\n    <div class="container">' in s:
        s = s.replace('<body>\n    <div class="container">', '<body>\n    ' + BAR.rstrip('\n'), 1)
    else:
        s = re.sub(r'(<body[^>]*>\s*)<div class="container">', lambda m: m.group(1) + BAR.rstrip('\n'), s, count=1)
    # Skip-link target: first section wrapper gets the id
    s = s.replace('<div class="progress-indicator"', '<div id="main-content" tabindex="-1"></div>\n        <div class="progress-indicator"', 1)
    # JS: prepend inside the last <script> block
    i = s.rfind('<script>')
    if i != -1:
        s = s[:i + len('<script>')] + JS + s[i + len('<script>'):]
    return s, 'ok'

if __name__ == '__main__':
    for f in sys.argv[1:]:
        s = open(f, encoding='utf-8').read()
        s2, st = add_a11y(s)
        if st == 'ok':
            open(f, 'w', encoding='utf-8').write(s2)
        print(f.split('/')[-1][:45], st)
