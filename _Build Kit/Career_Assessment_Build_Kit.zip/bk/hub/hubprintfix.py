# -*- coding: utf-8 -*-
"""Make Ctrl+P inside a hub print the full report, not a clipped iframe. Idempotent."""
MARK = '/* ---- Hub print fix (hubprintfix) ---- */'

CSS = '''
        ''' + MARK + '''
        @media print {
            body.printing-frame #menu,
            body.printing-frame .viewer-header { display: none !important; }
            html, body.printing-frame {
                height: auto !important; overflow: visible !important;
                background: #fff !important; }
            body.printing-frame #viewer {
                position: static !important; display: block !important;
                height: auto !important; overflow: visible !important;
                background: #fff !important; }
            body.printing-frame #assessment-frame {
                border: 0 !important; width: 6.5in !important; max-width: 100% !important;
                overflow: visible !important; }
        }
'''

JS = '''
/* ---- Hub print fix (hubprintfix) ---- */
(function () {
    var savedHeight = null, savedWidth = null;
    function frameEl() { return document.getElementById('assessment-frame'); }
    function beforePrint() {
        var v = document.getElementById('viewer'), f = frameEl();
        if (!v || !f || !v.classList.contains('show')) return;
        document.body.classList.add('printing-frame');
        try {
            var d = f.contentDocument;
            if (!d) return;
            var r = d.getElementById('report') || d.getElementById('reportSection');
            savedHeight = f.style.height;
            savedWidth = f.style.width;
            /* Reflow the frame to the printed page width first, so the height we
               measure is the height the report will actually occupy on paper. */
            f.style.width = '6.5in';
            void f.offsetWidth;
            var h;
            if (r && d.body && d.body.classList.contains('print-report')) {
                h = Math.ceil(r.scrollHeight * 1.12) + 120;   /* report only, with print-reflow headroom */
            } else {
                h = Math.max(d.documentElement.scrollHeight, d.body ? d.body.scrollHeight : 0);
            }
            f.style.height = h + 'px';
        } catch (e) {}
    }
    function afterPrint() {
        var f = frameEl();
        document.body.classList.remove('printing-frame');
        if (f && savedHeight !== null) { f.style.height = savedHeight; savedHeight = null; }
        if (f && savedWidth !== null) { f.style.width = savedWidth; savedWidth = null; }
    }
    window.addEventListener('beforeprint', beforePrint);
    window.addEventListener('afterprint', afterPrint);
})();
'''


def add_hubprintfix(s):
    if MARK in s:
        return s, 'already'
    i = s.rfind('</style>')
    if i == -1:
        return s, 'no </style>'
    s = s[:i] + CSS + '    ' + s[i:]
    j = s.rfind('</script>')
    if j == -1:
        return s, 'no </script>'
    return s[:j] + JS + s[j:], 'ok'
