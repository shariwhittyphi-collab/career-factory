import os,re,shutil
SP='/tmp/claude-0/-home-claude/f9343031-0377-5923-a467-67743b1e0be0/scratchpad'
SITE=SP+'/site'; shutil.rmtree(SITE,ignore_errors=True); os.makedirs(SITE)
CSS=open(SP+'/indexcss.txt').read().replace('</style>','''
.back-link{display:inline-flex;align-items:center;min-height:44px;margin-bottom:12px;color:var(--accent);font-weight:600;text-decoration:none}
.back-link:focus-visible{outline:3px solid var(--accent);outline-offset:2px;border-radius:6px}
.howto{background:var(--card);border:2px solid var(--accent);border-radius:12px;padding:18px 20px;margin:-12px 0 32px}
.howto h2{margin:0 0 8px;font-size:1.15rem;color:var(--ink)}
.howto p{margin:0;font-size:1.02rem}
.howto ol{margin:6px 0 0;padding-left:1.4em;display:grid;gap:4px}
.howto strong{color:var(--accent)}
.areas{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;margin-bottom:24px}
.area{display:flex;flex-direction:column;gap:6px;background:var(--card);border:1px solid var(--line);border-radius:12px;padding:20px;color:var(--ink);text-decoration:none;transition:border-color .2s,transform .2s}
.area:hover{border-color:var(--accent);transform:translateY(-1px)}
.area:focus-visible{outline:3px solid var(--accent);outline-offset:2px}
.area h3{margin:0;font-size:1.3rem;color:var(--accent)}
.area .n{font-size:.85rem;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--muted)}
.area p{margin:0;color:var(--muted);font-size:.95rem}
.area .go{margin-top:6px;font-weight:700;color:var(--accent)}
.area.soon{border-style:dashed;opacity:.72;cursor:default}
.area.soon:hover{border-color:var(--line);transform:none}
.area.soon h3{color:var(--muted)}
.area.soon .go{color:var(--muted);font-weight:700}
.soon-head{margin:28px 0 12px;font-size:1.05rem;color:var(--muted);font-weight:700;letter-spacing:.02em}
@media (forced-colors:active){.area.soon{opacity:1}}
@media (prefers-reduced-motion:reduce){.area{transition:none}.area:hover{transform:none}}
</style>''')
CATS=[('healthcare','Healthcare','Healthcare Web','Nurses, lab and imaging techs, therapists, dental, EMS and more.'),
      ('skilled-trades','Skilled Trades','Skilled Trades Web','Construction, mechanics, electricians, welders, energy and personal-service trades.'),
      ('tech','Tech','Tech Web','Help desk, networks, cybersecurity, software, data and more.'),
      ('social-services','Social Services','Social Services Web','Social workers, probation, health education, firefighters, police and childcare.'),
      ('transportation','Transportation','Transportation Web','Truck and school bus drivers, commercial pilots and air traffic controllers.'),
      ('business-finance','Business and Finance','Business and Finance Web','Accounting, HR, lending, insurance, logistics, marketing and project management.'),
      ('architecture-engineering','Architecture and Engineering','Architecture and Engineering Web','Engineers, architects, surveyors, drafters and engineering technicians.'),
      ('education','Education','Education Web','Teachers from preschool through high school, special education, career classes and adult learning.'),
      ('management','Management','Management Web','Supervisors and managers in business, plants, healthcare, engineering and community programs.'),
      ('science','Science','Science Web','Agriculture, chemistry, environmental science, workplace safety and city planning.'),
      ('arts-legal-sales','Arts, Legal and Sales','Arts Legal and Sales Web','Industrial design, public relations, paralegal work and technical sales.')]
HOWTO_CAT='''<section class="howto" aria-labelledby="howto-h">
  <h2 id="howto-h">How to use this page</h2>
  <p><strong>Tap a career below</strong> to learn what the job is like in North Dakota: the work, training, pay and job outlook.</p>
  <p style="margin-top:6px">At the end of each career, answer a few short questions to see if it could be a good fit for you.</p>
</section>'''
total=0
for slug,name,src,blurb in CATS:
    d=SITE+'/'+slug; shutil.copytree(SP+'/out/'+src,d)
    p=d+'/index.html'; s=open(p,encoding='utf-8').read()
    s=s.replace(' Tap any career to take a detailed assessment.','')
    s=s.replace('<header>','<a class="back-link" href="../index.html">&larr; All career areas</a>\n        <header>',1)
    s=s.replace('</header>','</header>\n'+HOWTO_CAT,1)
    s=re.sub(r'<style>.*?</style>',lambda m:CSS,s,count=1,flags=re.S)
    open(p,'w',encoding='utf-8').write(s)
    n=len([f for f in os.listdir(d) if f!='index.html']); total+=n
    CATS[CATS.index((slug,name,src,blurb))]=(slug,name,src,blurb,n)
# Areas not built yet. Fill from the In-Demand list; count=None hides the number.
COMING=[
]
soon='\n'.join(f'''      <div class="area soon" aria-label="{c[0]} — coming soon">
        <span class="n">{(str(c[1]) + (" career" if c[1]==1 else " careers")) if c[1] else "&nbsp;"}</span>
        <h3>{c[0]}</h3>
        <p>{c[2]}</p>
        <span class="go">Coming soon</span>
      </div>''' for c in COMING)
soon_block=(f'''    <h2 class="soon-head">Still being built &mdash; check back</h2>
    <section aria-label="Career areas coming soon" class="areas">
{soon}
    </section>
''' if COMING else '')
cards='\n'.join(f'''      <a class="area" href="{c[0]}/index.html">
        <span class="n">{c[4]} careers</span>
        <h3>{c[1]}</h3>
        <p>{c[3]}</p>
        <span class="go">See {c[1].lower()} careers &rarr;</span>
      </a>''' for c in CATS)
body=f'''<title>ND Career Assessments</title>
{CSS}
<main>
  <div class="container">
    <header>
      <h1>North Dakota In-Demand Career Assessments</h1>
      <p class="tagline">{('Explore all ' + str(total) + " careers on North Dakota's In-Demand Occupations list") if not COMING else ('Explore ' + str(total) + ' careers that North Dakota needs &mdash; with ' + str(sum(c[1] for c in COMING)) + ' more on the way')}</p>
      <p class="intro-text">Find out what each job is really like, how to get trained in North Dakota, what it pays, and whether it could be a good fit for you.</p>
    </header>
    <section class="howto" aria-labelledby="howto-h">
      <h2 id="howto-h">How it works</h2>
      <ol>
        <li><strong>Pick a career area</strong> below.</li>
        <li><strong>Tap a career</strong> to learn about it.</li>
        <li>Read about the job, then <strong>answer a few short questions</strong>.</li>
        <li><strong>See your results</strong> and your next steps.</li>
      </ol>
    </section>
    <section aria-label="Career areas" class="areas">
{cards}
    </section>
{soon_block}    <footer><p><strong>In-Demand Career Assessments</strong> &mdash; North Dakota</p></footer>
  </div>
</main>
'''
open(SP+'/site_artifact_index.html','w',encoding='utf-8').write(body)
open(SITE+'/index.html','w',encoding='utf-8').write('<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'+body.replace('<main>','</head>\n<body>\n<main>',1)+'</body>\n</html>\n')
print('careers',total)
