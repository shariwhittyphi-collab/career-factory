import re,os,sys,shutil,glob
SP='/tmp/claude-0/-home-claude/f9343031-0377-5923-a467-67743b1e0be0/scratchpad'
sys.path.insert(0,SP+'/bk/hub'); from lib import shrink_images,b64; from scrub import scrub_text,leftovers
U='/mnt/user-data/uploads/MHTML Careers'
OUT=SP+'/out'; os.makedirs(OUT,exist_ok=True)
HUBS={
 'health':dict(tpl=U+'/Career Hubs/Healthcare_Career_Assessments_UPDATED.html', name='Healthcare',
   file=lambda k: SP+'/work/health/'+k.replace(' Career Assessment','').replace(' ','_')+'_Career_Assessment.html'),
 'trades':dict(tpl=SP+'/trades_tpl.html', name='Skilled Trades',
   file=lambda k: SP+'/work/trades/'+{
    'Plumber, Pipefitter, and Steamfitter':'Plumber_Pipefitter','Industrial Electrical and Electronics Repairer':'Industrial_Electrical_Repairer',
    'Substation and Relay Technician':'Substation_Relay_Technician','Power Plant and Gas Plant Operator':'Power_and_Gas_Plant_Operator',
    'Power Distributor and Dispatcher':'Power_Dispatcher','Hairstylist and Cosmetologist':'Cosmetologist','Mortician and Funeral Director':'Mortician','Structural Iron and Steel Worker':'Structural_Iron_Steel_Worker','Power-Line Installer':'Power_Line_Installer','Stationary Engineer and Boiler Operator':'Stationary_Engineer_Boiler_Operator','RV Service Technician':'RV_Service_Technician',
   }.get(k.replace(' Career Assessment',''), k.replace(' Career Assessment','').replace(' ','_'))+'_Career_Assessment_Complete.html'),
 'tech':dict(tpl=U+'/Tech/Tech_Career_Assessments.html', name='Tech',
   file=lambda k: SP+'/work/tech/'+{'Software Quality Assurance Analyst and Tester':'Software_QA_Analyst_and_Tester'}.get(k.replace(' Career Assessment',''), k.replace(' Career Assessment','').replace(' ','_'))+'_Career_Assessment_Complete.html'),
 'soc':dict(tpl=SP+'/soc_tpl.html', name='Social Services',
   file=lambda k: SP+'/work/soc/'+{
    'Child, Family, and School Social Worker':'Child_Family_and_School_Social_Worker',
    'Social Worker, All Other':'Social_Worker_All_Other',
    'Police and Sheriff\u2019s Patrol Officer':'Police_and_Sheriffs_Patrol_Officer',
   }.get(k.replace(' Career Assessment',''), k.replace(' Career Assessment','').replace(' ','_'))+'_Career_Assessment_Complete.html'),
 'trans':dict(tpl=SP+'/trans_tpl.html', name='Transportation',
   file=lambda k: SP+'/work/trans/'+{
    'Heavy and Tractor-Trailer Truck Driver':'Heavy_and_Tractor_Trailer_Truck_Driver',
   }.get(k.replace(' Career Assessment',''), k.replace(' Career Assessment','').replace(' ','_'))+'_Career_Assessment_Complete.html'),
 'fin':dict(tpl=SP+'/fin_tpl.html', name='Business and Finance',
   file=lambda k: SP+'/work/fin/'+{
    'Compensation and Benefits Specialists':'Compensation_Benefits_and_Job_Analysis_Specialists',
    'Market Research Analysts':'Market_Research_Analysts',
    'Business Operations Specialists':'Business_Operations_Specialists',
    'Financial Specialists, All Other':'Financial_Specialists_All_Other',
   }.get(k.replace(' Career Assessment',''), k.replace(' Career Assessment','').replace(' ','_'))+'_Career_Assessment_Complete.html'),
}
SHIM='''<script>(function(){try{var t="__t";localStorage.setItem(t,t);localStorage.removeItem(t);}catch(e){var m={};try{Object.defineProperty(window,"localStorage",{configurable:true,value:{getItem:function(k){return k in m?m[k]:null},setItem:function(k,v){m[k]=String(v)},removeItem:function(k){delete m[k]},clear:function(){m={}}}});}catch(_){}}})();</script>'''
NAVCSS=open(SP+'/navcss.txt').read()
INDEXCSS=open(SP+'/indexcss.txt').read()
def slug(t): return re.sub(r'[^a-z0-9]+','-',t.replace(' Career Assessment','').lower()).strip('-')
cat=sys.argv[1]; H=HUBS[cat]
t=open(H['tpl'],encoding='utf-8').read()
order=re.findall(r"openAssessment\('([^']+)'\)",t)
pages={}; total_left=0
for k in order:
    h=open(H['file'](k),encoding='utf-8').read()
    h,n=scrub_text(h); total_left+=len(leftovers(h))
    h=shrink_images(h)
    pages[k]=h
# single-file hub
d0=t.index('var ASSESSMENTS_DATA = {'); d1=t.index('};',d0)+2
hub=t[:d0]+'var ASSESSMENTS_DATA = {\n'+',\n'.join(f'    "{k}": "{b64(pages[k])}"' for k in order)+'\n};'+t[d1:]
hub,_=scrub_text(hub)
lh=leftovers(re.sub(r'"[A-Za-z0-9+/=]{500,}"','',hub))
open(f"{OUT}/{H['name'].replace(' ','_')}_Career_Assessments.html",'w',encoding='utf-8').write(hub)
# web folder
W=f"{OUT}/{H['name']} Web"; shutil.rmtree(W,ignore_errors=True); os.makedirs(W)
for i,k in enumerate(order):
    h=pages[k]
    prev=f'<a href="{slug(order[i-1])}.html">&larr; Prev</a>' if i>0 else '<a class="dvr-off" aria-disabled="true">&larr; Prev</a>'
    nxt=f'<a href="{slug(order[i+1])}.html">Next &rarr;</a>' if i<len(order)-1 else '<a class="dvr-off" aria-disabled="true">Next &rarr;</a>'
    nav=f'<nav class="dvr-nav" aria-label="Career navigation"><a href="index.html">&#9776; All careers</a><span class="dvr-sp"></span><span class="dvr-count">{i+1} of {len(order)}</span>{prev}{nxt}</nav>'
    h=re.sub(r'(<head[^>]*>)',lambda m:m.group(1)+SHIM,h,count=1).replace('</head>',NAVCSS+'</head>',1)
    h=re.sub(r'(<body[^>]*>)',lambda m:m.group(1)+nav,h,count=1)
    open(f'{W}/{slug(k)}.html','w',encoding='utf-8').write(h)
i=t.index('<div id="menu">'); j=t.index('</footer>',i)+9
menu=t[i+len('<div id="menu">'):j]
menu=re.sub(r'<button class="career-card" onclick="openAssessment\(\'([^\']+)\'\)">(.*?)</button>',lambda m:f'<a class="career-card" href="{slug(m.group(1))}.html">{m.group(2)}</a>',menu,flags=re.S)
menu=re.sub(r'\s*<span class="visual-badge">✓ Visual</span>','',menu).replace('Click any career','Tap any career')
menu,_=scrub_text(menu)
title=f"{H['name']} Career Assessments"
body=f'<title>{title}</title>\n'+INDEXCSS+'\n<main>'+menu+'\n</main>\n'
open(f'{W}/index.html','w',encoding='utf-8').write('<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="UTF-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'+body.replace('<main>','</head>\n<body>\n<main>',1)+'</body>\n</html>\n')
open(f'{OUT}/{cat}_artifact_index.html','w',encoding='utf-8').write(body)
sz=os.path.getsize(f"{OUT}/{H['name'].replace(' ','_')}_Career_Assessments.html")/1048576
print(cat,len(order),'careers | hub %.1f MB'%sz,'| DVR left in pages:',total_left,'hub shell:',lh, '| footer:',re.search(r'<footer>.*?</footer>',menu,re.S).group(0)[:160])
