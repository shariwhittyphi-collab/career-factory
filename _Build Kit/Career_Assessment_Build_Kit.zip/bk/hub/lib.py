import re, base64, io
from PIL import Image
def shrink_images(h, max_w=1400, q=82):
    def rep(m):
        raw = base64.b64decode(m.group(2))
        im = Image.open(io.BytesIO(raw)).convert('RGB')
        if im.width > max_w:
            im = im.resize((max_w, round(im.height * max_w / im.width)), Image.LANCZOS)
        b = io.BytesIO(); im.save(b, 'JPEG', quality=q, optimize=True, progressive=True)
        return 'data:image/jpeg;base64,' + base64.b64encode(b.getvalue()).decode()
    return re.sub(r'data:image/(png|jpeg|jpg|webp);base64,([A-Za-z0-9+/=]+)', rep, h)
def b64(h): return base64.b64encode(h.encode('utf-8')).decode()
def card(title, name, desc, visual):
    badge = '\n                    <span class="visual-badge">✓ Visual</span>' if visual else ''
    return f'''                <button class="career-card" onclick="openAssessment('{title}')">
                    <div class="career-title">{name}</div>
                    <div class="career-description">{desc}</div>{badge}
                </button>'''
def section(color, icon, field, cards):
    n = len(cards)
    return f'''        <div class="field-section">
            <div class="field-header" style="border-color: {color};">
                <div class="field-icon" style="background-color: {color};">{icon}</div>
                <h2 class="field-title" style="color: {color};">{field}</h2>
                <span class="career-count">{n} career{'s' if n != 1 else ''}</span>
            </div>
            <div class="careers-grid">
''' + '\n'.join(cards) + '''
            </div>
        </div>'''
