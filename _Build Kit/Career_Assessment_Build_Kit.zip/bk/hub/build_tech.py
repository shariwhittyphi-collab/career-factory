import re, sys
sys.path.insert(0, '/home/claude/hub'); from lib import *
t = open('/mnt/user-data/outputs/Healthcare_Career_Assessments_UPDATED.html', encoding='utf-8').read()
U = '/mnt/user-data/uploads/Tech/'
NEW = [
 ('Computer User Support Specialist Career Assessment', 'Computer_User_Support_Specialist_Career_Assessment_Complete.html', 'Computer User Support Specialist', 'Help people fix computer, software, and account problems (help desk)'),
 ('Computer Network Support Specialist Career Assessment', 'Computer_Network_Support_Specialist_Career_Assessment_Complete.html', 'Computer Network Support Specialist', 'Keep networks, Wi-Fi, and internet connections running'),
 ('Network and Computer Systems Administrator Career Assessment', 'Network_and_Computer_Systems_Administrator_Career_Assessment_Complete.html', 'Network & Computer Systems Administrator', 'Run the servers, accounts, and cloud systems an organization depends on'),
 ('Information Security Analyst Career Assessment', 'Information_Security_Analyst_Career_Assessment_Complete.html', 'Information Security Analyst', 'Protect computers and data from hackers and scams'),
 ('Software Developer Career Assessment', 'Software_Developer_Career_Assessment_Complete.html', 'Software Developer', 'Design and build apps and programs'),
 ('Software QA Analyst and Tester Career Assessment', 'Software_QA_Analyst_and_Tester_Career_Assessment_Complete.html', 'Software QA Analyst & Tester', 'Find bugs and problems before software goes out'),
 ('Web Developer Career Assessment', 'Web_Developer_Career_Assessment_Complete.html', 'Web Developer', 'Build websites and web apps that work on every screen'),
]
data, cards = {}, {}
for k, f, n, d in NEW:
    h = open(U + f, encoding='utf-8').read()
    data[k] = b64(shrink_images(h)); cards[k] = card(k, n, d, '<img' in h)
S = [section('#1f6fb2', '🖥️', 'IT Support & Networks', [cards[k] for k, *_ in NEW[:3]]),
     section('#8a3b12', '🛡️', 'Cybersecurity', [cards[NEW[3][0]]]),
     section('#2f7d4f', '💻', 'Software & Web', [cards[k] for k, *_ in NEW[4:]])]
order = [k for k, *_ in NEW]
bs = t.index('        <div class="field-section">'); be = t.index('    </div>\n\n    <footer>')
t2 = t[:bs] + '\n\n'.join(S) + '\n' + t[be:]
d0 = t2.index('var ASSESSMENTS_DATA = {'); d1 = t2.index('};', d0) + 2
t2 = t2[:d0] + 'var ASSESSMENTS_DATA = {\n' + ',\n'.join(f'    "{k}": "{data[k]}"' for k in order) + '\n};' + t2[d1:]
rep = {'<title>Healthcare Career Discovery</title>': '<title>Tech Career Discovery</title>',
       '<h1>Healthcare Career Assessments</h1>': '<h1>Tech Career Assessments</h1>',
       re.search(r'Explore \d+ In-Demand Healthcare Careers in North Dakota', t2).group(0): 'Explore 7 In-Demand Tech Careers in North Dakota',
       'Discover what different healthcare roles involve': 'Discover what different tech roles involve',
       'In-Demand Healthcare Career Assessments</strong>': 'In-Demand Tech Career Assessments</strong>'}
for a, b in rep.items():
    assert a in t2, a; t2 = t2.replace(a, b)
assert 'ealthcare' not in re.sub(r'"[^"]+": "[A-Za-z0-9+/=]+"', '', t2), [m.start() for m in re.finditer('ealthcare', t2)][:5]
open('/mnt/user-data/outputs/Tech_Career_Assessments.html', 'w', encoding='utf-8').write(t2)
print(round(len(t2.encode())/1048576, 2), 'MB')
