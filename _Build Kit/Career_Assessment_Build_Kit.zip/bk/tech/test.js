const { chromium } = require('playwright');
const fs = require('fs'), path = require('path');
(async () => {
  const b = await chromium.launch();
  const files = [...fs.readdirSync('out/it2').filter(f=>f.endsWith('.html')).map(f=>'out/it2/'+f)];
  for (const f of files) {
    const p = await b.newPage(); const errs = [];
    p.on('pageerror', e => errs.push(e.message)); p.on('console', m => m.type()==='error' && errs.push(m.text()));
    await p.goto('file://' + path.resolve(f));
    for (let i = 1; i < 9; i++) await p.click(`#section${i} .btn-primary`);
    await p.click('#section9 .btn-primary');            // no answer -> should block
    const blocked9 = await p.isVisible('#section9') && await p.isVisible('#alertBox');
    await p.click('#section9 input[value="' + (await p.getAttribute('#section9 input >> nth=1','value')) + '"]');
    await p.click('#section9 .btn-primary');
    for (let i = 1; i <= 7; i++) await p.click(`input[name=readiness${i}][value=yes]`);
    await p.click('#section10 .btn-primary');
    const blocked10 = (await p.textContent('#alertBox')).includes('8');
    await p.click('input[name=readiness8][value=unsure]');
    await p.click('#section10 .btn-primary');
    await p.click('input[name=future] >> nth=0');
    await p.fill('#comments', '<b>test</b> & "quotes"');
    await p.click('#section11 .btn-primary');
    const rep = await p.textContent('#reportContent');
    const ok = rep.includes('9 / 10') && rep.includes('7 / 8') && rep.includes('<b>test</b>') && rep.includes('you said: unsure');
    await p.screenshot({ path: 'shot_' + path.basename(f, '.html') + '.png', fullPage: true });
    console.log(path.basename(f), {blocked9, blocked10, reportOK: ok, errs});
    await p.close();
  }
  await b.close();
})();
