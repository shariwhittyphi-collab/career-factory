"""Add a Listen button to the RESULTS screen (the report section).

tools.py deliberately skips the report section, so the eleven content sections got a
Listen button and the results screen did not. That is the screen a reader with a
reading disability most needs read aloud. This adds one, next to Print Report.

Run after tools.py. Idempotent.
Usage: python3 reportlisten.py file1.html ...   (edits in place)
Importable: from reportlisten import add_report_listen
"""
import re, sys

MARK = 'listenReport(this)'

CSS = """
        /* ---- Listen button inside the results button group ---- */
        .button-group .tool-btn { flex: 0 1 auto; padding: 0.75rem 1.5rem; font-size: 1rem; border-radius: 6px; }
        @media (max-width: 600px) { .button-group .tool-btn { width: 100% !important; flex: 1 1 100%; } }
"""

BTN = ('<button type="button" class="btn-secondary tool-btn" data-label="&#128266; Listen to my results" '
       'aria-pressed="false" onclick="listenReport(this)">&#128266; Listen to my results</button>\n                ')

JS = """
        // ---- Listen to the results report ----
        function listenReport(btn) {
            if (!ttsSupported()) return;
            var wasThis = (ttsBtn === btn);
            stopSpeech();
            if (wasThis) return;
            var sec = document.getElementById('report') || document.getElementById('reportSection');
            if (!sec) return;
            var txt = sectionText(sec);
            if (!txt) return;
            var u = new SpeechSynthesisUtterance(txt);
            u.rate = 0.95;
            u.onend = ttsReset;
            u.onerror = ttsReset;
            ttsBtn = btn;
            btn.classList.add('speaking');
            btn.innerHTML = '\\u25A0 Stop';
            btn.setAttribute('aria-pressed', 'true');
            try { window.speechSynthesis.speak(u); } catch (e) { ttsReset(); }
        }
"""


def add_report_listen(s):
    if MARK in s:
        return s, 'already'
    # the report section's own button group is the one holding Print Report
    # Current template: the button group that holds Print Report.
    m = re.search(r'<div class="button-group">\s*(?=<button[^>]*onclick="printPage\(\))', s)
    # Older healthcare templates (CNA/LPN/RN): button group holding Start Over.
    if not m:
        m = re.search(r'<div class="button-group"[^>]*>\s*(?=<button[^>]*onclick="restartAssessment\(\))', s)
    # Oldest (Phlebotomy/Radiographic): a bare print button, no group before it.
    if not m:
        m = re.search(r'(?=<button class="print-btn" onclick="window\.print\(\))', s)
    if not m:
        return s, 'no report button group'
    s = s[:m.end()] + BTN + s[m.end():]
    s = s.replace('</style>', CSS + '    </style>', 1)
    i = s.rfind('</script>')
    if i == -1:
        return s, 'no script'
    return s[:i] + JS + s[i:], 'ok'


if __name__ == '__main__':
    for f in sys.argv[1:]:
        s = open(f, encoding='utf-8').read()
        s2, st = add_report_listen(s)
        if st == 'ok':
            open(f, 'w', encoding='utf-8').write(s2)
        print(f.split('/')[-1][:50], st)
