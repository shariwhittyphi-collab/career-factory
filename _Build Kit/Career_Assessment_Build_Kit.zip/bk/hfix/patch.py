import sys, os, glob
CSS = """
        /* ---- Sept 27 2026 fixes: print, dark-mode readability, unanswered-question alert ---- */
        @media print {
            .button-group, .progress-indicator, .fix-alert { display: none !important; }
            .section, header { box-shadow: none; }
        }
        @media (prefers-color-scheme: dark) {
            :root { --accent-blue: #6cb4ff; }
            .report { background: #1f2f45 !important; }
            .btn-primary, .section-number { background-color: #0066cc; }
            .radio-option:hover { background-color: #0a2a55; }
        }
        .fix-alert { background: #fff4e5; color: #663c00; border-left: 5px solid #e68a00; padding: 0.75rem 1rem;
                     border-radius: 4px; margin-top: 1rem; font-weight: 600; }
        @media (prefers-color-scheme: dark) { .fix-alert { background: #3d2a00; color: #ffd699; } }
    """
JS = r"""
    <script>
    /* ---- Sept 27 2026 fixes: no freeze on skipped questions, safe comments, readable plan text ---- */
    (function () {
        function clearAlert() { var a = document.querySelector('.fix-alert'); if (a) a.remove(); }
        function showAlert(sectionEl, msg) {
            clearAlert();
            var a = document.createElement('div');
            a.className = 'fix-alert'; a.setAttribute('role', 'alert'); a.textContent = msg;
            var bg = sectionEl.querySelector('.button-group');
            if (bg) bg.parentNode.insertBefore(a, bg); else sectionEl.appendChild(a);
        }
        function goTo(n) {
            document.querySelectorAll('.section').forEach(function (s) { s.classList.remove('active'); });
            document.getElementById('section' + n).classList.add('active');
            currentSection = n; updateProgress(); window.scrollTo(0, 0);
        }
        function missingIn(sectionEl) {
            var names = [], seen = {};
            sectionEl.querySelectorAll('input[type=radio]').forEach(function (r) {
                if (!seen[r.name]) { seen[r.name] = 1; names.push(r.name); }
            });
            return names.filter(function (n) { return !document.querySelector('input[name="' + n + '"]:checked'); });
        }
        function numberOf(name) { var m = name.match(/(\d+)$/); return m ? m[1] : null; }

        var origNext = nextSection;
        nextSection = function () {
            var sec = document.getElementById('section' + currentSection);
            var miss = missingIn(sec);
            if (miss.length) {
                var nums = miss.map(numberOf).filter(Boolean);
                showAlert(sec, nums.length ? 'Please answer question' + (nums.length > 1 ? 's ' : ' ') + nums.join(', ') + ' before you continue.'
                                           : 'Please pick an answer before you continue.');
                return;
            }
            clearAlert(); origNext();
        };
        var origPrev = prevSection;
        prevSection = function () { clearAlert(); origPrev(); };

        var origReport = generateReport;
        generateReport = function () {
            for (var i = 1; i <= 11; i++) {
                var sec = document.getElementById('section' + i);
                if (!sec) continue;
                var miss = missingIn(sec);
                if (miss.length) {
                    if (i !== currentSection) goTo(i);
                    showAlert(sec, 'A question on this page was skipped. Please answer it, then get your results.');
                    return;
                }
            }
            clearAlert();
            var box = document.getElementById('comments'), raw = box ? box.value : '';
            if (box) box.value = raw.replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; });
            try { origReport(); } finally { if (box) box.value = raw; }
            var f = document.querySelector('input[name="future"]:checked');
            if (f && f.parentNode) {
                var label = f.parentNode.textContent.trim(), plain = f.value.replace(/_/g, ' ');
                document.querySelectorAll('#reportContent em').forEach(function (em) { if (em.textContent === plain) em.textContent = label; });
            }
        };
    })();
    </script>
"""
for src in sys.argv[1:]:
    t = open(src, encoding='utf-8').read()
    assert t.count('</style>') == 1 and t.count('</body>') == 1 and 'Sept 27 2026 fixes' not in t
    t = t.replace('@print {', '@media print {', 1)
    t = t.replace('</style>', CSS + '</style>', 1)
    t = t.replace('</body>', JS + '</body>', 1)
    out = src.replace('/mnt/user-data/uploads/', '/mnt/user-data/outputs/Healthcare Fixed/')
    os.makedirs(os.path.dirname(out), exist_ok=True)
    open(out, 'w', encoding='utf-8').write(t)
    print('patched', out)
