const { chromium } = require('playwright');
(async()=>{const b=await chromium.launch();
for (const [f,shot] of [['/mnt/user-data/outputs/Healthcare_Career_Assessments_UPDATED.html','h.png'],['/mnt/user-data/outputs/Tech_Career_Assessments.html','t.png']]){
 const p=await b.newPage({viewport:{width:1280,height:900}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
 await p.goto('file://'+f); await p.screenshot({path:shot,fullPage:true});
 const cards=await p.$$eval('.career-card',c=>c.map(x=>x.getAttribute('onclick').match(/'(.+)'/)[1]));
 const keys=await p.evaluate(()=>ASSESSMENT_TITLES);
 const out=[];
 for(let i=0;i<cards.length;i++){
   await p.click(`.career-card >> nth=${i}`); await p.waitForTimeout(300);
   const fr=p.frames()[1];
   const r=await fr.evaluate(()=>({h1:(document.querySelector('h1')||{}).textContent,imgs:[...document.images].filter(i=>i.naturalWidth>0).length,broken:[...document.images].filter(i=>i.complete&&i.naturalWidth===0).length}));
   // run one quick skip test on assessments with nextSection
   let alertOK=null;
   if(await fr.evaluate(()=>typeof nextSection==='function' && !!document.getElementById('section9'))){
     await fr.evaluate(()=>{for(let i=0;i<8;i++)nextSection();nextSection();});
     alertOK=await fr.evaluate(()=>!!(document.querySelector('.fix-alert.show, .alert.show, .fix-alert')));
   }
   out.push([cards[i].slice(0,40),r.h1&&r.h1.slice(0,40),r.imgs,r.broken,alertOK]);
   await p.click('text=Back to Menu');
 }
 console.log(f.split('/').pop(),'cards',cards.length,'keys',keys.length,'order match',JSON.stringify(cards)===JSON.stringify(keys),'errs',errs);
 out.forEach(o=>console.log('  ',o.join(' | ')));
 await p.close();}
await b.close();})();
