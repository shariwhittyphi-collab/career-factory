"""Add a "shorter path" panel to the results report.

Shari's idea: when someone answers No or Not Sure to the question about committing to the
education, the report currently just scores them lower and stops. This adds a panel naming
real, shorter-training careers in the SAME field - and, where it is true, says that the
shorter job counts as a step back toward this one. The door stays open.

Careers where the training is already short have no education barrier question and get no
panel. That is correct, not a gap.

add_stepping(s, edu_q, steps, closer) -> (s, status)
  edu_q  : the radio group name of the education/time question, e.g. 'readiness1'
  steps  : list of (career name, how long the training is, one short why-it-counts line)
  closer : one sentence tying it together, or '' for none
Idempotent. Run after reportlisten.py.
"""
import json, sys

MARK = '/* ---- Shorter path panel ---- */'

CSS = """
        /* ---- Shorter path panel ---- */
        .shorter { border: 2px solid #0b4f8a !important; border-radius: 10px; padding: 18px 20px; margin: 1.5rem 0 0;
            background: #eef5ff !important; color: #1a1a1a !important; }
        .shorter * { color: #1a1a1a !important; }
        .shorter h3 { margin: 0 0 6px; color: #0b4f8a !important; }
        .shorter .lead { margin: 0 0 12px; }
        .shorter ul { list-style: none; margin: 0; padding: 0; }
        .shorter li { padding: 10px 0; border-top: 1px solid var(--border-color); }
        .shorter li:first-child { border-top: 0; }
        .shorter .nm { font-weight: 700; color: #0b4f8a !important; }
        .shorter .hm { font-weight: 600; white-space: nowrap; color: #0b4f8a !important; }
        .shorter .wy { display: block; font-size: 0.95rem; margin-top: 2px; }
        .shorter .closer { margin: 12px 0 0; font-weight: 600; }
        html[data-theme="dark"] .shorter { background: #12283f !important; border-color: #8cc4ff !important; color: #e8eef5 !important; }
        html[data-theme="dark"] .shorter * { color: #e8eef5 !important; }
        html[data-theme="dark"] .shorter h3, html[data-theme="dark"] .shorter .nm,
        html[data-theme="dark"] .shorter .hm { color: #8cc4ff !important; }
        @media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) .shorter { background: #12283f !important; border-color: #8cc4ff !important; }
            :root:not([data-theme="light"]) .shorter * { color: #e8eef5 !important; }
            :root:not([data-theme="light"]) .shorter h3, :root:not([data-theme="light"]) .shorter .nm,
            :root:not([data-theme="light"]) .shorter .hm { color: #8cc4ff !important; } }
        @media print { .shorter, html[data-theme="dark"] .shorter { border: 1px solid #999 !important; background: #fff !important; }
            .shorter *, html[data-theme="dark"] .shorter * { color: #000 !important; }
            .shorter h3, .shorter .nm, .shorter .hm { color: #0b4f8a !important; } }
"""

JS_TMPL = """
        // ---- Shorter path panel (shows only if the education question is No / Not Sure) ----
        var STEP_Q = %s, STEP_LIST = %s, STEP_CLOSER = %s;
        function stepAnswer() {
            var r = document.querySelector('input[name="' + STEP_Q + '"]:checked');
            return r ? String(r.value).toLowerCase() : '';
        }
        function renderShorterPath() {
            var host = document.getElementById('reportContent') || document.getElementById('report') || document.getElementById('reportSection');
            if (!host || !STEP_LIST.length) return;
            var old = document.getElementById('shorterPath');
            if (old) old.parentNode.removeChild(old);
            var a = stepAnswer();
            if (a !== 'no' && a !== 'unsure' && a !== 'notsure' && a !== 'not sure' && a !== 'maybe') return;
            var d = document.createElement('div');
            d.className = 'shorter'; d.id = 'shorterPath';
            var h = '<h3>Not ready for all that school? Start here instead.</h3>'
                  + '<p class="lead">These are real jobs in the same field. They take less training, and they pay from day one.</p><ul>';
            for (var i = 0; i < STEP_LIST.length; i++) {
                h += '<li><span class="nm">' + STEP_LIST[i][0] + '</span> \\u2014 <span class="hm">' + STEP_LIST[i][1] + '</span>'
                   + '<span class="wy">' + STEP_LIST[i][2] + '</span></li>';
            }
            h += '</ul>';
            if (STEP_CLOSER) { h += '<p class="closer">' + STEP_CLOSER + '</p>'; }
            d.innerHTML = h;
            host.appendChild(d);
        }
        (function () {
            if (typeof window.generateReport === 'function') {
                var _gr = window.generateReport;
                window.generateReport = function () { var r = _gr.apply(this, arguments); try { renderShorterPath(); } catch (e) {} return r; };
            }
        })();
"""


def add_stepping(s, edu_q, steps, closer=''):
    if MARK in s:
        return s, 'already'
    if not edu_q or not steps:
        return s, 'skip (no education barrier)'
    if '</style>' not in s:
        return s, 'no style'
    s = s.replace('</style>', CSS + '    </style>', 1)
    js = JS_TMPL % (json.dumps(edu_q), json.dumps([list(x) for x in steps]), json.dumps(closer))
    i = s.rfind('</script>')
    if i == -1:
        return s, 'no script'
    return s[:i] + js + s[i:], 'ok'


if __name__ == '__main__':
    print(__doc__)
