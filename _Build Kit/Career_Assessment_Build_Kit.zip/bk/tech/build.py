"""Builds the Tech career assessments in the same 11-section format as the healthcare series."""
import html, json, re, sys
sys.path.insert(0, '/home/claude/tech')
from careers_data import CAREERS
from healthcare_data import HEALTH
from healthcare2_data import HEALTH2
from healthcare3_data import HEALTH3
from trades_a import TRADES_A
from trades_b import TRADES_B
from trades_c import TRADES_C
from trades_d1 import TRADES_D1
from trades_d2 import TRADES_D2
from trades_d3 import TRADES_D3
from it2_data import IT2
from soc_a import SOC_A
from soc_b import SOC_B
from trans_a import TRANS_A
from fin_a import FIN_A
from fin_b import FIN_B
from fin_c import FIN_C
from fin_d import FIN_D
from fin_e import FIN_E
from eng_a import ENG_A
from eng_b import ENG_B
from eng_c import ENG_C
from eng_d import ENG_D
from edu_a import EDU_A
from edu_b import EDU_B
from edu_c import EDU_C
from edu_d import EDU_D
from mgmt_a import MGMT_A
from mgmt_b import MGMT_B
from sci_a import SCI_A
from als_a import ALS_A
from back_a import BACK_A

TPL = open('/home/claude/tpl/Paramedic_Career_Assessment_Complete.html').read()
CSS = re.search(r'<style>(.*?)</style>', TPL, re.S).group(1)
# Fixes to the shared template CSS
CSS = CSS.replace('@print {', '@media print {')
CSS = CSS.replace("""            @media (prefers-color-scheme: dark) {""", """            @media (prefers-color-scheme: dark) {""")
CSS += """
        /* Additions for the Tech series */
        @media (prefers-color-scheme: dark) {
            :root { --accent-blue: #6cb4ff; }
            .report { background: #1f2f45 !important; }
            .btn-primary, .section-number { background-color: #0066cc; }
            .alert { background: #3d2a00; color: #ffd699; }
            .radio-option:hover { background-color: #0a2a55; }
        }
        .section h2:focus { outline: none; }
        .section h2:focus-visible { outline: 3px solid var(--accent-blue); outline-offset: 4px; }
        .radio-option:focus-within { border-color: var(--accent-blue); }
        .alert { display: none; background: #fff4e5; color: #663c00; border-left: 5px solid #e68a00;
                 padding: 0.75rem 1rem; border-radius: 4px; margin-top: 1rem; font-weight: 600; }
        .alert.show { display: block; }
        .source-note { font-size: 0.85rem; color: var(--text-light) !important; margin-top: 1rem; }
        .img-slot { margin: 1.25rem 0; }
        .img-slot img { max-width: 100%; height: auto; border-radius: 8px; }
        fieldset { border: none; }
        legend { font-weight: 600; margin-bottom: 1rem; color: var(--text-dark); }
        @media print {
            .section { display: none !important; }
            #report { display: block !important; box-shadow: none; }
            header { box-shadow: none; }
        }
"""

e = html.escape

def nav(first=False, last=False, report=False):
    b = []
    if not first:
        b.append('<button class="btn-secondary" onclick="prevSection()">Back</button>')
    if report:
        b.append('<button class="btn-primary" onclick="generateReport()">Get My Results</button>')
    else:
        b.append('<button class="btn-primary" onclick="nextSection()">%s</button>' % ("Let's Begin" if first else 'Continue'))
    return '<div class="button-group">\n                ' + '\n                '.join(b) + '\n            </div>'

def img_slot(c, key):
    # Placeholder for Chadwick. Invisible until an <img> is dropped inside.
    return f'<!-- CHADWICK IMAGE ({key}): {c["images"][key] or "optional extra picture"} -->\n            <div class="img-slot" data-image="{key}"></div>'

def section(n, title, body, **kw):
    return f'''
        <div class="section{' active' if n == 1 else ''}" id="section{n}">
            <h2 tabindex="-1"><span class="section-number" aria-hidden="true">{n}</span>{title}</h2>
            {body}
            {nav(**kw)}
        </div>'''

def ul(items):
    return '<ul>\n' + '\n'.join(f'                <li>{i}</li>' for i in items) + '\n            </ul>'

def radio_group(name, options, legend):
    opts = '\n'.join(
        f'''                    <label class="radio-option"><input type="radio" name="{name}" value="{v}"> {lab}</label>'''
        for v, lab in options)
    return f'''<div class="assessment-question">
                <fieldset>
                <legend>{legend}</legend>
                <div class="radio-group">
{opts}
                </div>
                </fieldset>
            </div>'''

def build(c):
    w = c['wages']; p = c['proj']
    s = []
    s.append(section(1, 'Welcome', ''.join(f'<p>{x}</p>' for x in c['welcome']) +
                     '<p><strong>This takes about 15 minutes.</strong></p>', first=True))
    s.append(section(2, f"What is a {c['name']}?",
        f"<p>{c['what']}</p>\n            {img_slot(c,'what')}\n            <p><strong>The Reality:</strong> {c['reality']}</p>\n"
        f"            <p><strong>Your Responsibilities:</strong></p>\n            {ul(c['duties'])}\n            <p>{c['what_close']}</p>"))
    day = '\n            '.join(f'<p><strong>{t}</strong> — {d}</p>' for t, d in c['day'])
    s.append(section(3, 'A Day in the Life', f"{img_slot(c,'day')}\n            {day}\n            <p>{c['day_close']}</p>"))
    tr = c['training']
    s.append(section(4, 'Training in North Dakota',
        f"<p><strong>{tr['headline']}</strong> {tr['intro']}</p>\n            {img_slot(c,'training')}\n"
        f"            <p><strong>Training Pathways:</strong></p>\n            {ul(tr['paths'])}\n"
        f"            <p><strong>Where to Train in North Dakota:</strong></p>\n            {ul(tr['programs'])}\n"
        f"            <p><strong>Before You Start:</strong> {tr['prereq']}</p>\n            <p><strong>Tip:</strong> {tr['tip']}</p>"))
    ce = c['cert']
    s.append(section(5, 'Certification & Licensing',
        f"<p><strong>{ce['headline']}</strong> {ce['intro']}</p>\n            <p><strong>{ce.get('list_label','Certifications Employers Look For')}:</strong></p>\n            {ul(ce['list'])}\n"
        f"            <p><strong>The Exams:</strong> {ce['exam']}</p>\n            <p><strong>Cost:</strong> {ce['cost']}</p>\n            <p><strong>Keeping It Current:</strong> {ce['renew']}</p>"))
    if c.get('annual_only'):
        # Contract jobs (teachers) have no BLS hourly wage. Show yearly pay only.
        sal = [
            f"Starting out (bottom 10–25%): ${w['a10']}–${w['a25']} a year",
            f"Middle (median — half earn more, half earn less): ${w['a50']} a year",
            f"Experienced (top 25–10%): ${w['a75']}–${w['a90']} a year",
        ]
    else:
        sal = [
            f"Starting out (bottom 10–25%): ${w['h10']}–${w['h25']}/hour (${w['a10']}–${w['a25']}/year)",
            f"Middle (median — half earn more, half earn less): ${w['h50']}/hour (${w['a50']}/year)",
            f"Experienced (top 25–10%): ${w['h75']}–${w['h90']}/hour (${w['a75']}–${w['a90']}/year)",
        ]
    s.append(section(6, 'Salary & Job Outlook',
        (f"<p><strong>{c.get('wage_label', 'North Dakota ' + c['plural'] + ' Pay (May 2025)')}:</strong></p>\n            {ul(sal)}\n"
        f"            <p><strong>What that means:</strong> {c['pay_note']}</p>\n")
        + (f"            <p><strong>Jobs in North Dakota:</strong> {p['text']}</p>\n" if p.get('text') else f"            <p><strong>Jobs in North Dakota:</strong> About {p['nd_now']:,} {p.get('who', 'people do this work')} in ND{'' if 'count' in p.get('who','') else ' today'}. By {p.get('end', 2034)}, that should be about {p['nd_2034']:,} "
        f"({p['nd_pct']}). Expect {'about ' if isinstance(p['openings'], int) else ''}<strong>{p['openings']} job openings every year</strong> in ND from growth and people retiring or changing jobs. Across the U.S., the change is {p['us_pct']}.</p>\n") +
        f"            <p><strong>Outlook:</strong> {c['outlook']}</p>\n"
        f"            <p><strong>Who Hires in ND:</strong> {c['employers']}</p>\n"
        f"            <p><strong>Work Setting:</strong> {c['setting']}</p>\n"
        f"            <p><strong>Physical Demands:</strong> {c['physical']}</p>\n"
        f"            <p class=\"source-note\">Sources: U.S. Bureau of Labor Statistics, Occupational Employment and Wage Statistics, {c.get('wage_scope', 'North Dakota')}, May 2025 (SOC {c['soc']}); "
        f"{c.get('proj_source', 'North Dakota and U.S. long-term employment projections 2024–2034')}, via O*NET OnLine. Numbers are rounded.</p>"))
    paths = '\n            '.join(f'<p><strong>Path {i}: {n}</strong> — {d}</p>' for i, (n, d) in enumerate(c['paths'], 1))
    s.append(section(7, 'Where This Leads', f"{img_slot(c,'paths')}\n            {paths}"))
    s.append(section(8, 'The Real Talk',
        f"<p><strong>What's Great:</strong></p>\n            {ul(c['great'])}\n            <p><strong>What's Hard:</strong></p>\n            {ul(c['hard'])}\n"
        f"            <p><strong>Be Honest:</strong> {c['honest']}</p>"))
    s.append(section(9, 'Part 1: What Attracts You?',
        radio_group('motivation', [(v, l) for v, l, _ in c['motivation']], c['motivation_q'])))
    rq = '\n            '.join(radio_group(f'readiness{i}', [('yes', 'Yes'), ('unsure', 'Unsure'), ('no', 'No')], f'{i}. {q}')
                                for i, q in enumerate(c['readiness'], 1))
    s.append(section(10, 'Part 2: Are You Ready?', rq))
    s.append(section(11, 'Part 3: Your Next Move',
        radio_group('future', c['future'], "What's your plan?") +
        '\n            <div class="assessment-question">\n                <label for="comments" style="font-weight:600;display:block;margin-bottom:1rem;">Any other thoughts?</label>\n'
        '                <textarea id="comments" placeholder="Optional..." rows="4"></textarea>\n            </div>', report=True))

    data = {
        'name': c['name'],
        'scores': {v: sc for v, _, sc in c['motivation']},
        'motLabels': {v: l for v, l, _ in c['motivation']},
        'futureLabels': {v: l for v, l in c['future']},
        'recs': c['recs'], 'nextSteps': c['next_steps'], 'finalWords': c['final'],
        'readinessItems': c['readiness'],
    }
    out = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{c['name']} Career Assessment</title>
    <style>{CSS}    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>{c['name']} Career Assessment</h1>
            <p class="subtitle">{c['subtitle']}</p>
        </header>

        <div class="progress-indicator" aria-live="polite">
            <span id="progress">Section 1 of 11</span>
        </div>
{''.join(s)}

        <div class="section" id="report">
            <h2 tabindex="-1">Your {c['name']} Assessment Results</h2>
            <div class="report" id="reportContent"></div>
            <div class="button-group">
                <button class="btn-secondary" onclick="printPage()">Print Report</button>
                <button class="btn-secondary" onclick="location.reload()">Start Over</button>
            </div>
        </div>
        <div class="alert" id="alertBox" role="alert"></div>
    </div>

    <script>
        const DATA = {json.dumps(data, ensure_ascii=False)};
        let currentSection = 1;

        function show(id) {{
            document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
            const el = document.getElementById(id);
            el.classList.add('active');
            hideAlert();
            window.scrollTo(0, 0);
            const h = el.querySelector('h2');
            if (h) h.focus({{preventScroll: true}});
        }}

        function hideAlert() {{ document.getElementById('alertBox').classList.remove('show'); }}
        function alertMsg(msg) {{
            const a = document.getElementById('alertBox');
            a.textContent = msg;
            const sec = document.getElementById('section' + currentSection);
            sec.querySelector('.button-group').before(a);
            a.classList.add('show');
        }}

        function checked(name) {{
            const el = document.querySelector('input[name="' + name + '"]:checked');
            return el ? el.value : null;
        }}

        function nextSection() {{
            if (currentSection === 9 && !checked('motivation')) {{
                alertMsg('Please pick the answer that fits you best before you continue.');
                return;
            }}
            if (currentSection === 10) {{
                const missing = [];
                for (let i = 1; i <= 8; i++) if (!checked('readiness' + i)) missing.push(i);
                if (missing.length) {{
                    alertMsg('Please answer question' + (missing.length > 1 ? 's ' : ' ') + missing.join(', ') + ' before you continue.');
                    return;
                }}
            }}
            currentSection++;
            show('section' + currentSection);
            updateProgress();
        }}

        function prevSection() {{
            currentSection--;
            show('section' + currentSection);
            updateProgress();
        }}

        function updateProgress() {{
            document.getElementById('progress').textContent = 'Section ' + currentSection + ' of 11';
        }}

        function esc(s) {{
            return s.replace(/[&<>"']/g, ch => ({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}})[ch]);
        }}

        function generateReport() {{
            const future = checked('future');
            if (!future) {{ alertMsg('Please pick your plan before you get your results.'); return; }}
            const motivation = checked('motivation');
            const readiness = [];
            for (let i = 1; i <= 8; i++) readiness.push(checked('readiness' + i));
            const comments = document.getElementById('comments').value.trim();

            const readinessScore = readiness.filter(r => r === 'yes').length;
            const motivationScore = DATA.scores[motivation];

            let readinessLevel = readinessScore >= 7 ? 'Strong' : readinessScore >= 5 ? 'Moderate' : 'Low';

            let recommendation;
            if (motivationScore >= 8 && readinessScore >= 7) recommendation = DATA.recs[0];
            else if (motivationScore >= 8 && readinessScore >= 6) recommendation = DATA.recs[1];
            else if (motivationScore >= 7 && readinessScore >= 5) recommendation = DATA.recs[2];
            else if (motivationScore >= 5) recommendation = DATA.recs[3];
            else recommendation = DATA.recs[4];

            const toWork = [];
            readiness.forEach((r, i) => {{ if (r !== 'yes') toWork.push(DATA.readinessItems[i] + (r === 'unsure' ? ' (you said: unsure)' : ' (you said: no)')); }});

            const html = `
                <h3>Motivation Score: ${{motivationScore}} / 10</h3>
                <p>You said: <em>${{esc(DATA.motLabels[motivation])}}</em></p>
                <p>${{motivationScore >= 8 ? 'Strong motivation.' : motivationScore >= 6 ? 'Good interest. Get clear on what you want from this job.' : 'Not sure yet. Explore more before you spend money on training.'}}</p>
                <div class="score-bar"><div class="score-fill" style="width: ${{motivationScore * 10}}%"></div></div>

                <h3>${{readinessLevel}} Readiness: ${{readinessScore}} / 8</h3>
                <p>${{readinessScore >= 7 ? 'You look ready.' : readinessScore >= 5 ? 'You have most of what it takes.' : 'Some gaps exist. That is OK. Now you know what to work on.'}}</p>
                <div class="score-bar"><div class="score-fill" style="width: ${{readinessScore * 12.5}}%"></div></div>
                ${{toWork.length ? '<p><strong>Things to work on or look into:</strong></p><ul style="margin-left: 1.5rem;">' + toWork.map(t => '<li>' + esc(t) + '</li>').join('') + '</ul>' : ''}}

                <h3>The Verdict</h3>
                <p><strong>${{recommendation}}</strong></p>

                <h3>Your Plan</h3>
                <p><em>${{esc(DATA.futureLabels[future])}}</em></p>
                ${{comments ? '<p><strong>Your thoughts:</strong> "' + esc(comments) + '"</p>' : ''}}

                <h3>Next Steps</h3>
                <ul style="margin-left: 1.5rem;">${{DATA.nextSteps.map(s => '<li>' + s + '</li>').join('')}}</ul>

                <h3>Final Words</h3>
                <p>${{DATA.finalWords}}</p>
            `;

            document.getElementById('reportContent').innerHTML = html;
            show('report');
            document.getElementById('progress').textContent = 'Results';
        }}

        function printPage() {{ window.print(); }}
    </script>
</body>
</html>
'''
    return out

if __name__ == '__main__':
    import os
    which = sys.argv[1] if len(sys.argv) > 1 else 'tech'
    for c in {'health': HEALTH, 'health2': HEALTH2, 'health3': HEALTH3, 'trades': TRADES_A + TRADES_B + TRADES_C, 'trades2': TRADES_D1 + TRADES_D2 + TRADES_D3, 'it2': IT2, 'soc': SOC_A + SOC_B, 'trans': TRANS_A, 'fin': FIN_A + FIN_B + FIN_C + FIN_D + FIN_E, 'eng': ENG_A + ENG_B + ENG_C + ENG_D, 'edu': EDU_A + EDU_B + EDU_C + EDU_D, 'mgmt': MGMT_A + MGMT_B, 'sci': SCI_A, 'als': ALS_A, 'back': BACK_A}.get(which, CAREERS):
        fn = f"/home/claude/tech/out/{which}/{c['file']}"
        os.makedirs(os.path.dirname(fn), exist_ok=True)
        open(fn, 'w').write(build(c))
        print('wrote', fn)
