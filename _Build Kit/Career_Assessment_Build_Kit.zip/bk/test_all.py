import asyncio,glob,re,os
from playwright.async_api import async_playwright
SP='/tmp/claude-0/-home-claude/f9343031-0377-5923-a467-67743b1e0be0/scratchpad/out'
FILL="""()=>{const g={};document.querySelectorAll('input[type=radio]').forEach(x=>(g[x.name]=g[x.name]||[]).push(x));
Object.values(g).forEach(a=>a[0].click());document.querySelectorAll('textarea').forEach(t=>{t.value='Test';t.dispatchEvent(new Event('input',{bubbles:true}))});
generateReport();const r=document.getElementById('report')||document.getElementById('reportSection');
return r?[getComputedStyle(r).display!=='none', r.innerText.length]:[false,0]}"""
async def main():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    for hub in ['Healthcare_Career_Assessments.html','Skilled_Trades_Career_Assessments.html','Tech_Career_Assessments.html','Social_Services_Career_Assessments.html','Transportation_Career_Assessments.html','Business_and_Finance_Career_Assessments.html']:
      c=await b.new_context(viewport={'width':1280,'height':900}); pg=await c.new_page(); errs=[]
      pg.on('pageerror',lambda e: errs.append(str(e)[:120])); pg.on('dialog',lambda d: asyncio.ensure_future(d.dismiss()))
      await pg.goto('file://'+SP+'/'+hub)
      keys=await pg.evaluate('Object.keys(ASSESSMENTS_DATA)'); bad=[]
      for i,k in enumerate(keys):
        await pg.evaluate(f'openAssessment({k!r})'); await pg.wait_for_timeout(250)
        fr=pg.frame_locator('#assessment-frame')
        f=[x for x in pg.frames if x!=pg.main_frame][0]
        try: r=await f.evaluate(FILL)
        except Exception as e: r=[False,str(e)[:80]]
        if not (r[0] and r[1]>300): bad.append((k,r))
        await pg.evaluate('closeViewer()')
      # prev/next
      await pg.evaluate(f'openAssessment({keys[0]!r})'); nx=[]
      for _ in range(len(keys)-1):
        await pg.click('#next-btn'); nx.append(await pg.inner_text('#viewer-title'))
      print(hub,len(keys),'cards | report failures:',bad,'| next-walk ok:',nx==keys[1:],'| next disabled at end:',await pg.is_disabled('#next-btn'),'| errors:',errs[:3])
      await c.close()
    for W in ['Healthcare Web','Skilled Trades Web','Tech Web','Social Services Web','Transportation Web','Business and Finance Web']:
      c=await b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True); pg=await c.new_page(); errs=[]
      pg.on('pageerror',lambda e: errs.append(str(e)[:120])); pg.on('dialog',lambda d: asyncio.ensure_future(d.dismiss()))
      await pg.goto('file://'+SP+'/'+W+'/index.html')
      links=await pg.eval_on_selector_all('a.career-card','els=>els.map(e=>e.getAttribute("href"))')
      bad=[]; navbad=[]
      for h in links:
        await pg.goto('file://'+SP+'/'+W+'/'+h)
        r=await pg.evaluate(FILL)
        if not (r[0] and r[1]>300): bad.append((h,r))
        hrefs=await pg.eval_on_selector_all('.dvr-nav a[href]','els=>els.map(e=>e.getAttribute("href"))')
        for x in hrefs:
          if not os.path.exists(SP+'/'+W+'/'+x): navbad.append((h,x))
      print(W,len(links),'pages | report failures:',bad,'| broken nav links:',navbad,'| errors:',errs[:3])
      await c.close()
    await b.close()
asyncio.run(main())
