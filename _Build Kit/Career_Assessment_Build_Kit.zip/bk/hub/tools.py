"""Add per-section Listen (read aloud) and Print-this-part buttons to a career assessment page.
Usage: python3 tools.py file1.html ...   (edits in place)
Importable: from tools import add_tools
Idempotent: skips a file that already has them.
"""
import re, sys

CSS = """
        /* ---- Listen and print controls ---- */
        .tool-row { display: flex; flex-wrap: wrap; gap: 0.5rem; margin: 0 0 1.2rem; }
        .tool-btn { width: auto !important; flex: 0 0 auto; min-height: 44px; padding: 0.4rem 0.9rem;
            cursor: pointer; font-size: 0.95rem; background: var(--light-gray); color: var(--text-dark);
            border: 2px solid var(--border-color); border-radius: 6px; font-family: inherit; font-weight: 600; }
        .tool-btn:hover { border-color: var(--accent-blue); }
        .tool-btn.speaking { background: var(--accent-blue); color: #fff; border-color: var(--accent-blue); }
        .tool-btn:focus-visible { outline: 3px solid var(--accent-blue); outline-offset: 2px; }
        @media print {
            .tool-row { display: none !important; }
            body.print-one .section { display: none !important; }
            body.print-one .section.print-me { display: block !important; box-shadow: none; }
            body.print-one #report, body.print-one #reportSection { display: none !important; }
        }
"""

JS = """
        // ---- Listen (read aloud) and print-one-section ----
        var ttsBtn = null;
        function ttsSupported() { return typeof window.speechSynthesis !== 'undefined' && typeof window.SpeechSynthesisUtterance !== 'undefined'; }
        function ttsReset() {
            if (ttsBtn) {
                ttsBtn.classList.remove('speaking');
                ttsBtn.innerHTML = ttsBtn.getAttribute('data-label');
                ttsBtn.setAttribute('aria-pressed', 'false');
                ttsBtn = null;
            }
        }
        function stopSpeech() { try { if (ttsSupported()) window.speechSynthesis.cancel(); } catch (e) {} ttsReset(); }
        function sectionText(sec) {
            var c = sec.cloneNode(true);
            var drop = c.querySelectorAll('.tool-row, .button-group, script, .img-slot, .section-number');
            for (var i = 0; i < drop.length; i++) { drop[i].parentNode.removeChild(drop[i]); }
            return (c.innerText || c.textContent || '').replace(/\\s+/g, ' ').trim();
        }
        function listenSection(btn, id) {
            if (!ttsSupported()) return;
            var wasThis = (ttsBtn === btn);
            stopSpeech();
            if (wasThis) return;
            var sec = document.getElementById(id);
            if (!sec) return;
            var txt = sectionText(sec);
            if (!txt) return;
            var u = new SpeechSynthesisUtterance(txt);
            u.rate = 0.95;
            u.onend = ttsReset;
            u.onerror = ttsReset;
            ttsBtn = btn;
            btn.classList.add('speaking');
            btn.innerHTML = '\\u25A0 Stop';
            btn.setAttribute('aria-pressed', 'true');
            try { window.speechSynthesis.speak(u); } catch (e) { ttsReset(); }
        }
        function printSection(id) {
            var sec = document.getElementById(id);
            if (!sec) return;
            stopSpeech();
            var old = document.querySelectorAll('.print-me');
            for (var i = 0; i < old.length; i++) { old[i].classList.remove('print-me'); }
            sec.classList.add('print-me');
            document.body.classList.add('print-one');
            try { window.print(); } catch (e) {}
            setTimeout(function () {
                document.body.classList.remove('print-one');
                sec.classList.remove('print-me');
            }, 800);
        }
        (function () {
            if (!ttsSupported()) {
                var b = document.querySelectorAll('.tool-btn[data-label]');
                for (var i = 0; i < b.length; i++) { b[i].style.display = 'none'; }
            }
            window.addEventListener('beforeunload', stopSpeech);
            var names = ['nextSection', 'prevSection', 'goToSection', 'showSection', 'generateReport'];
            for (var j = 0; j < names.length; j++) {
                (function (n) {
                    if (typeof window[n] === 'function') {
                        var orig = window[n];
                        window[n] = function () { stopSpeech(); return orig.apply(this, arguments); };
                    }
                })(names[j]);
            }
        })();
"""

ROW = ('<div class="tool-row" role="group" aria-label="Section tools">'
       '<button type="button" class="tool-btn" data-label="&#128266; Listen" aria-pressed="false" '
       'onclick="listenSection(this,\'{sid}\')">&#128266; Listen</button>'
       '<button type="button" class="tool-btn" onclick="printSection(\'{sid}\')">'
       '&#128424;&#65039; Print this part</button></div>')


def add_tools(s):
    if 'tool-row' in s:
        return s, 'already'
    s = s.replace('</style>', CSS + '    </style>', 1)

    # Insert a tool row right after each section's <h2>...</h2>
    def repl(m):
        sid = m.group('sid') or m.group('sid2')
        if sid in ('report', 'reportSection'):
            return m.group(0)
        return m.group(0) + '\n            ' + ROW.format(sid=sid)

    pat = re.compile(r'<div (?:class="section[^"]*" id="(?P<sid>[^"]+)"|id="(?P<sid2>[^"]+)" class="section[^"]*")>\s*<h2[^>]*>.*?</h2>', re.S)
    s, n = pat.subn(repl, s)

    i = s.rfind('</script>')
    if i != -1:
        s = s[:i] + JS + s[i:]
    return s, ('ok %d' % n)


if __name__ == '__main__':
    for f in sys.argv[1:]:
        s = open(f, encoding='utf-8').read()
        s2, st = add_tools(s)
        if st.startswith('ok'):
            open(f, 'w', encoding='utf-8').write(s2)
        print(f.split('/')[-1][:50], st)
