# -*- coding: utf-8 -*-
"""Adds a "Sources & Learn More" block to an assessment page. Idempotent.

Every link points at the page that actually holds the information, not an
organisation's front door.
"""
import re, html, json

MARK = '<!-- Sources & Learn More (sources.py) -->'
CSS_MARK = '/* ---- Sources & Learn More ---- */'

CSS = '''
        ''' + CSS_MARK + '''
        .srcsec { display: block !important; background: #f4f8fc; border: 1px solid #c7d9ea;
            border-left: 5px solid #0b4f8a; border-radius: 10px; padding: 18px 20px;
            margin: 28px auto 8px; max-width: 900px; color: #1a1a1a; }
        html[data-theme="dark"] .srcsec { background: #14293f; border-color: #2d4a68;
            border-left-color: #6fb1ec; color: #e6ecf1; }
        .srcsec h2 { margin: 0 0 6px; font-size: 1.2rem; color: #0b4f8a; }
        html[data-theme="dark"] .srcsec h2 { color: #8cc4ff; }
        .srcsec .src-intro { margin: 0 0 12px; font-size: .95rem; }
        .srcsec dl { margin: 0; display: grid; gap: 10px; }
        .srcsec dt { font-weight: 700; font-size: .95rem; }
        .srcsec dd { margin: 2px 0 0; font-size: .95rem; line-height: 1.55; }
        .srcsec a { color: #0b4f8a; font-weight: 600; }
        html[data-theme="dark"] .srcsec a { color: #8cc4ff; }
        .srcsec a:focus-visible { outline: 3px solid #0b4f8a; outline-offset: 2px; }
        .srcsec .src-note { margin: 14px 0 0; font-size: .85rem; opacity: .85; }
        @media print {
            body.print-report:not(.print-one) .srcsec {
                display: block !important; background: #fff !important;
                border: 1px solid #999 !important; border-left: 4px solid #0b4f8a !important;
                page-break-inside: avoid; }
            body.print-report:not(.print-one) .srcsec h2 { color: #0b4f8a !important; }
            body.print-report:not(.print-one) .srcsec a { color: #000 !important;
                text-decoration: none; }
            body.print-one .srcsec { display: none !important; }
            body.print-one .srcsec.print-me { display: block !important;
                background: #fff !important; border: 1px solid #999 !important;
                border-left: 4px solid #0b4f8a !important; }
            body.print-one .srcsec.print-me h2 { color: #0b4f8a !important; }
            body.print-one .srcsec.print-me a { color: #000 !important; }
        }
'''

BLOCK = '''
    ''' + MARK + '''
    <div class="srcsec" id="sources" data-section-name="sources">
        <div class="tool-row"><button type="button" class="tool-btn" data-label="&#128266; Listen" aria-pressed="false" onclick="listenSection(this,'sources')">&#128266; Listen</button><button type="button" class="tool-btn" onclick="printSection('sources')">&#128424;&#65039; Print this part</button></div>
        <h2>Sources &amp; Learn More</h2>
        <p class="src-intro">Everything on this page comes from these sources. Each one opens the page the information came from, so you can check it yourself or keep reading.</p>
        <dl>
            <dt>Career information</dt>
            <dd><a href="%(summary)s" target="_blank" rel="noopener">%(label)s on O*NET OnLine</a> &mdash; what the job involves, the skills it uses, and related jobs.</dd>

            <dt>Pay and employment data</dt>
            <dd><a href="%(wages)s" target="_blank" rel="noopener">North Dakota pay for %(plural)s</a> &mdash; from the U.S. Bureau of Labor Statistics Occupational Employment and Wage Statistics survey, May 2025.<br>
            <a href="%(trends)s" target="_blank" rel="noopener">North Dakota job outlook, 2024&ndash;2034</a> &mdash; state projections from Projections Central.</dd>

            <dt>Education and training</dt>
            <dd><a href="%(training)s" target="_blank" rel="noopener">North Dakota schools that train %(plural)s</a> &mdash; colleges and programs in this state, with how many people finished recently. From the U.S. Department of Labor, using federal college data (IPEDS).</dd>

            <dt>More career exploration</dt>
            <dd><a href="https://secure.ruready.nd.gov/Career_Planning/_default.aspx" target="_blank" rel="noopener">RUReady.ND.gov career planning</a> &mdash; North Dakota&rsquo;s own career and college planning site. An account may be required.</dd>
        </dl>
        <p class="src-note">Pay and outlook figures on this page were taken from the sources above in September 2026. Occupation code: %(soc)s. Numbers are updated by the agencies over time, so check the links for the newest figures.</p>
    </div>
'''

BASE = 'https://www.onetonline.org/link/'


def _plural(name):
    n = name.strip()
    if n.endswith(('s', 'x', 'ch', 'sh')):
        return n + 'es' if not n.endswith('s') else n
    if n.endswith('y') and not n.endswith(('ay', 'ey', 'iy', 'oy', 'uy')):
        return n[:-1] + 'ies'
    return n + 's'


def add_sources(s, career_name, soc):
    """Returns (html, note). soc must be a full O*NET-SOC code like '29-1141.00'."""
    if MARK in s:
        return s, 'already'
    if not soc or not re.match(r'^\d{2}-\d{4}\.\d{2}$', soc):
        return s, 'skip (bad soc %r)' % (soc,)

    label = html.escape(career_name)
    plural = html.escape(_plural(career_name))
    vals = dict(
        label=label, plural=plural, soc=html.escape(soc),
        summary=BASE + 'summary/' + soc,
        wages=BASE + 'localwages/' + soc + '?st=ND',
        trends=BASE + 'localtrends/' + soc + '?st=ND',
        training=BASE + 'localtraining/' + soc + '?st=ND',
    )

    i = s.rfind('</style>')
    if i == -1:
        return s, 'no </style>'
    s = s[:i] + CSS + '    ' + s[i:]

    block = BLOCK % vals
    # Place it after the last section / before the page footer, outside the
    # stepped navigation so no template's section counter is touched.
    m = None
    for pat in (r'<footer[\s>]', r'</body>'):
        mm = list(re.finditer(pat, s))
        if mm:
            m = mm[-1]
            break
    if not m:
        return s, 'no insertion point'
    return s[:m.start()] + block + '\n    ' + s[m.start():], 'ok'
