import re, base64, sys
sys.path.insert(0, '/home/claude/hub'); from lib import *
SRC = '/mnt/user-data/outputs/Healthcare_Career_Assessments_UPDATED.html'
t = open(SRC, encoding='utf-8').read()
data = {m.group(1): m.group(2) for m in re.finditer(r'"([^"]+)": "([A-Za-z0-9+/=]+)"', t)}
U = '/mnt/user-data/uploads/Claudes Files for careers/'
NEW = {
 'Midwife Career Assessment': 'Midwife_Career_Assessment_Complete.html',
 'Cardiovascular Technologist Career Assessment': 'Cardiovascular_Technologist_Career_Assessment_Complete.html',
 'Clinical Laboratory Technologist Career Assessment': 'Clinical_Laboratory_Technologist_Career_Assessment_Complete.html',
 'Neurodiagnostic Technologist Career Assessment': 'Neurodiagnostic_Technologist_Career_Assessment_Complete.html',
 'Athletic Trainer Career Assessment': 'Athletic_Trainer_Career_Assessment_Complete.html',
 'Massage Therapist Career Assessment': 'Massage_Therapist_Career_Assessment_Complete.html',
 'Dietitian and Nutritionist Career Assessment': 'Dietitian_and_Nutritionist_Career_Assessment_Complete.html',
 'Medical Records Specialist Career Assessment': 'Medical_Records_Specialist_Career_Assessment_Complete.html',
 'Health Information Technologist Career Assessment': 'Health_Information_Technologist_and_Medical_Registrar_Career_Assessment_Complete.html',
}
visual = {}
for k, f in NEW.items():
    h = open(U + f, encoding='utf-8').read()
    visual[k] = '<img' in h
    data[k] = b64(shrink_images(h))
C = lambda k, n, d: card(k, n, d, visual.get(k, True))
S = [
 section('#0a7d7d', '👩‍⚕️', 'Nursing', [
   C('CNA Career Assessment', 'Certified Nurse Aide', 'Provide direct patient care, assist with daily activities, and support nursing staff'),
   C('LPN Career Assessment', 'Licensed Practical Nurse', 'Perform patient care, administer medications, and support nursing teams'),
   C('RN Career Assessment', 'Registered Nurse', 'Coordinate patient care, administer medications, and lead healthcare teams'),
   C('Midwife Career Assessment', 'Nurse-Midwife', 'Care for families through pregnancy, birth, and after (advanced practice nursing)')]),
 section('#6b4d9e', '🔬', 'Diagnostic Technology & Imaging', [
   C('Radiographic Technology Career Assessment', 'Radiographic Technologist', 'Operate X-ray equipment to create diagnostic images'),
   C('Diagnostic Medical Sonographer Career Assessment', 'Diagnostic Medical Sonographer', 'Use ultrasound equipment to create diagnostic images'),
   C('MRI Technologist Career Assessment', 'MRI Technologist', 'Operate magnetic resonance imaging equipment'),
   C('Nuclear Medicine Technologist Career Assessment', 'Nuclear Medicine Technologist', 'Administer radioactive substances and operate imaging equipment'),
   C('Cardiovascular Technologist Career Assessment', 'Cardiovascular Technologist', 'Run heart tests, heart ultrasounds, and assist in the cath lab'),
   C('Neurodiagnostic Technologist Career Assessment', 'Neurodiagnostic Technologist', 'Record brain and nerve activity (EEG) to help diagnose seizures and more'),
   C('Clinical Laboratory Technologist Career Assessment', 'Clinical Laboratory Technologist', 'Test blood and tissue samples to help diagnose disease'),
   C('Phlebotomy Career Assessment', 'Phlebotomy Technician', 'Collect blood samples for laboratory testing')]),
 section('#c41e3a', '🚑', 'Emergency, Surgery & Acute Care', [
   C('Emergency Medical Technician Career Assessment', 'Emergency Medical Technician', 'Respond to medical emergencies and provide emergency care'),
   C('Paramedic Career Assessment', 'Paramedic', 'Provide advanced emergency medical services'),
   C('Surgical Technologist Career Assessment', 'Surgical Technologist', 'Prepare the operating room and assist surgeons during procedures')]),
 section('#4a7c59', '💪', 'Therapy & Rehabilitation', [
   C('Physical Therapist Assistant Career Assessment', 'Physical Therapist Assistant', 'Help patients recover physical function through therapeutic exercises'),
   C('Occupational Therapy Assistant Career Assessment', 'Occupational Therapy Assistant', 'Help patients develop skills for daily living and work'),
   C('Respiratory Therapist Career Assessment', 'Respiratory Therapist', 'Help patients with breathing and respiratory conditions'),
   C('Athletic Trainer Career Assessment', 'Athletic Trainer', 'Prevent, treat, and rehab injuries for athletes and active people'),
   C('Massage Therapist Career Assessment', 'Massage Therapist', 'Use hands-on care to relieve pain and stress'),
   C('Dietitian and Nutritionist Career Assessment', 'Dietitian and Nutritionist', 'Use food and nutrition to help people manage health')]),
 section('#d89b6d', '🦷', 'Oral Health', [
   C('Dental Hygienist Career Assessment', 'Dental Hygienist', 'Provide preventive dental care and patient education'),
   C('Dental Assistant Career Assessment', 'Dental Assistant', 'Assist dentists with patient care and office operations'),
   C('Ophthalmic Medical Technician Career Assessment', 'Ophthalmic Medical Technician', 'Assist eye care professionals with patient exams')]),
 section('#556b8a', '🤝', 'Support Services', [
   C('Medical Assistant Career Assessment', 'Medical Assistant', 'Provide patient care and support clinical operations'),
   C('Medical Records Specialist Career Assessment', 'Medical Records Specialist', 'Code health records for billing and insurance (often remote)'),
   C('Health Information Technologist Career Assessment', 'Health Information Technologist & Registrar', 'Manage health data, records systems, and disease registries'),
   C('Veterinary Technologist Career Assessment', 'Veterinary Technologist', 'Assist veterinarians with animal care')]),
]
order = re.findall(r"openAssessment\('([^']+)'\)", '\n'.join(S))
assert set(order) == set(data), (set(order) ^ set(data))
body_start = t.index('        <div class="field-section">'); body_end = t.index('    </div>\n\n    <footer>')
t2 = t[:body_start] + '\n\n'.join(S) + '\n' + t[body_end:]
d0 = t2.index('var ASSESSMENTS_DATA = {'); d1 = t2.index('};', d0) + 2
t2 = t2[:d0] + 'var ASSESSMENTS_DATA = {\n' + ',\n'.join(f'    "{k}": "{data[k]}"' for k in order) + '\n};' + t2[d1:]
t2 = t2.replace('Explore In-Demand Healthcare Careers in North Dakota', f'Explore {len(order)} In-Demand Healthcare Careers in North Dakota')
open(SRC, 'w', encoding='utf-8').write(t2)
print(len(order), 'assessments;', round(len(t2.encode())/1048576, 2), 'MB; no-picture:', [k for k, v in visual.items() if not v])
