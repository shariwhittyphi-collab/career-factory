# -*- coding: utf-8 -*-
"""Unified print behaviour + printed report heading. Idempotent."""
import re, json

MARK = '/* ---- Unified print behavior (printfix2) ---- */'

CSS = '''
    ''' + MARK + '''
    .print-title { display: none; }
    @media print {
        body.print-report:not(.print-one) .section { display: none !important; }
        body.print-report:not(.print-one) #report,
        body.print-report:not(.print-one) #reportSection {
            display: block !important; box-shadow: none !important; }
        body.print-report:not(.print-one) #report .section,
        body.print-report:not(.print-one) #reportSection .section { display: block !important; }
        body.print-report:not(.print-one) .print-title { display: block !important; }
        html, body, .container, header, .section, .report, .report-section,
        html[data-theme="dark"] html, html[data-theme="dark"] body,
        html[data-theme="dark"] .container, html[data-theme="dark"] header,
        html[data-theme="dark"] .section, html[data-theme="dark"] .report,
        html[data-theme="dark"] .report-section {
            background: #fff !important; background-color: #fff !important;
            background-image: none !important; color: #000 !important; }
        .print-title h2 { color: #0b4f8a !important; margin: 0 0 4px; font-size: 20px; }
        .print-title p { color: #000 !important; margin: 0 0 14px; font-size: 13px; }
        .print-title { border-bottom: 2px solid #0b4f8a; padding-bottom: 8px; margin-bottom: 14px; }
    }
'''

JS = '''
        /* ---- Unified print behavior (printfix2) ---- */
        (function () {
            var CAREER = %s;
            function reportEl() {
                return document.getElementById('report') || document.getElementById('reportSection');
            }
            function ensureTitle(r) {
                if (!r || r.querySelector('.print-title')) return;
                var d = document.createElement('div');
                d.className = 'print-title';
                var h = document.createElement('h2');
                h.textContent = CAREER + ' \\u2014 Career Assessment Report';
                var p = document.createElement('p');
                var now = new Date();
                p.textContent = 'Printed ' + now.toLocaleDateString();
                d.appendChild(h); d.appendChild(p);
                r.insertBefore(d, r.firstChild);
            }
            function check() {
                var r = reportEl();
                var on = !!(r && r.offsetHeight > 0 && !document.body.classList.contains('print-one'));
                if (on) { ensureTitle(r); document.body.classList.add('print-report'); }
                else if (!document.body.classList.contains('print-one')) {
                    document.body.classList.remove('print-report');
                }
            }
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', check);
            } else { check(); }
            setInterval(check, 400);
            window.addEventListener('beforeprint', check);
        })();
'''


def _career_from_filename(fn):
    n = fn
    for suf in ('.html', '_Complete', '_Career_Assessment'):
        if n.endswith(suf):
            n = n[: -len(suf)]
    for suf in ('_Complete', '_Career_Assessment', '_Assessment'):
        if n.endswith(suf):
            n = n[: -len(suf)]
    return n.replace('_', ' ').strip()


def add_printfix2(s, filename):
    """Returns (html, note)."""
    if MARK in s:
        return s, 'already'
    career = _career_from_filename(filename)

    # 1. Scope the legacy "hide every section" print rule so an ungenerated
    #    report can never produce a blank print-out.
    before = s
    s = re.sub(
        r'(@media print\s*\{\s*)\.section\s*\{\s*display:\s*none\s*!important;\s*\}\s*'
        r'#report\s*\{\s*display:\s*block\s*!important;',
        r'\1body.print-report .section { display: none !important; }\n'
        r'            body.print-report #report { display: block !important;',
        s)
    scoped_a = s != before

    # 2. Scope the Phlebotomy/Radiographic "show every section" print rule.
    before = s
    s = re.sub(
        r'(@media print\s*\{\s*\.controls,\s*\.button-group,\s*\.print-btn\s*\{[^}]*\}\s*)'
        r'\.section\s*\{',
        r'\1body:not(.print-report) .section {',
        s)
    scoped_c = s != before

    # 3. Name the career in the on-screen report heading when it is anonymous.
    named = False
    if '<h2>Your Assessment Report</h2>' in s:
        s = s.replace('<h2>Your Assessment Report</h2>',
                      '<h2>Your ' + career + ' Assessment Report</h2>')
        named = True

    # 4. Canonical CSS + JS.
    i = s.rfind('</style>')
    if i == -1:
        return s, 'no </style>'
    s = s[:i] + CSS + '    ' + s[i:]
    j = s.rfind('</script>')
    if j == -1:
        return s, 'no </script>'
    s = s[:j] + (JS % json.dumps(career)) + s[j:]

    tags = []
    if scoped_a: tags.append('scopedA')
    if scoped_c: tags.append('scopedC')
    if named: tags.append('named')
    return s, 'ok' + (' (' + ','.join(tags) + ')' if tags else '')
