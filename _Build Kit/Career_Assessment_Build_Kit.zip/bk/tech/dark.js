const { chromium } = require('playwright'); const path=require('path');
(async()=>{const b=await chromium.launch();const p=await b.newPage({colorScheme:'dark'});
await p.goto('file://'+path.resolve('out/tech/Information_Security_Analyst_Career_Assessment_Complete.html'));
for(let i=1;i<6;i++) await p.click(`#section${i} .btn-primary`);
await p.screenshot({path:'dark6.png',fullPage:true});await b.close();})();
