const { chromium } = require('playwright');
(async()=>{const b=await chromium.launch();const p=await b.newPage();const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///mnt/user-data/outputs/Healthcare_Career_Assessments_UPDATED.html');
const titles=await p.evaluate(()=>ASSESSMENT_TITLES);
const res={};
for(const t of titles){
  await p.evaluate(t=>openAssessment(t),t); await p.waitForTimeout(400);
  const f=p.frame({url:/about:srcdoc/})||p.frames()[1];
  const r=await f.evaluate(()=>({fixed:!!document.querySelector('style')&&document.documentElement.innerHTML.includes('Sept 27 2026 fixes'),imgs:[...document.images].filter(i=>i.complete&&i.naturalWidth>0).length}));
  if(r.fixed){ // try skip flow
    await f.evaluate(()=>{for(let i=0;i<8;i++)nextSection();}); await f.evaluate(()=>nextSection());
    r.alert=await f.evaluate(()=>!!document.querySelector('.fix-alert'));
  }
  res[t.slice(0,30)]=r; await p.evaluate(()=>closeViewer());
}
console.log(res, 'errs',errs);await b.close();})();
