"""Make the results report follow the manual light/dark toggle, and always print on white.

Two bugs this fixes:
 1. The generator only styled the report for @media (prefers-color-scheme: dark), so a reader who
    pressed the Dark mode button on a light device kept the pale report card under light text, and
    a reader who pressed Light mode on a dark device got a dark card under dark text. These rules
    key off html[data-theme=...], which is what the toggle actually sets.
 2. Printing while in dark mode produced a dark page. The print block forces white paper and black
    ink whatever the screen theme, drops gradients, and prints score bars as solid gray.

Run this on every NEW assessment, after tools.py, before building a hub.
Usage: python3 darkfix.py file1.html ...   (edits in place)
Importable: from darkfix import add_darkfix, add_printfix
Both are idempotent.
"""
import sys

MARK = '/* ---- Report colors for the manual light/dark toggle ---- */'

CSS = """
        /* ---- Report colors for the manual light/dark toggle ---- */
        html[data-theme="dark"] .report,
        html[data-theme="dark"] .report-section {
            background: #1f2f45 !important;
            background-image: none !important;
            color: #e8eef5 !important;
        }
        html[data-theme="dark"] .report *,
        html[data-theme="dark"] .report-section * { color: inherit; }
        html[data-theme="dark"] .report h1, html[data-theme="dark"] .report h2,
        html[data-theme="dark"] .report h3, html[data-theme="dark"] .report h4,
        html[data-theme="dark"] .report strong,
        html[data-theme="dark"] .report-section h1, html[data-theme="dark"] .report-section h2,
        html[data-theme="dark"] .report-section h3, html[data-theme="dark"] .report-section h4,
        html[data-theme="dark"] .report-section strong { color: #8cc4ff !important; }
        html[data-theme="dark"] .report em, html[data-theme="dark"] .report-section em { color: #cfe0f0 !important; }
        html[data-theme="dark"] .alert { background: #3d2a00 !important; color: #ffd699 !important; }
        html[data-theme="dark"] .alert strong { color: #ffd699 !important; }
        html[data-theme="dark"] .radio-option:hover { background-color: #0a2a55 !important; }

        html[data-theme="light"] .report,
        html[data-theme="light"] .report-section {
            background: #eef5ff !important;
            background-image: none !important;
            color: #1a1a1a !important;
        }
        html[data-theme="light"] .report *,
        html[data-theme="light"] .report-section * { color: inherit; }
        html[data-theme="light"] .report h1, html[data-theme="light"] .report h2,
        html[data-theme="light"] .report h3, html[data-theme="light"] .report h4,
        html[data-theme="light"] .report strong,
        html[data-theme="light"] .report-section h1, html[data-theme="light"] .report-section h2,
        html[data-theme="light"] .report-section h3, html[data-theme="light"] .report-section h4,
        html[data-theme="light"] .report-section strong { color: #0b4f8a !important; }
        html[data-theme="light"] .alert { background: #fff8e1 !important; color: #5d4037 !important; }
        html[data-theme="light"] .alert strong { color: #5d4037 !important; }
"""

PRINT_MARK = '/* ---- Print always on white, whatever theme is on screen ---- */'

PRINT_CSS = """
        /* ---- Print always on white, whatever theme is on screen ---- */
        @media print {
            html, body, .container, header, .section, .report, .report-section { background: #fff !important; background-image: none !important; color: #000 !important; }
            html[data-theme="dark"] body, html[data-theme="dark"] .container, html[data-theme="dark"] header, html[data-theme="dark"] .section, html[data-theme="dark"] .report, html[data-theme="dark"] .report-section { background: #fff !important; background-image: none !important; color: #000 !important; }
            html[data-theme="light"] body, html[data-theme="light"] .container, html[data-theme="light"] header, html[data-theme="light"] .section, html[data-theme="light"] .report, html[data-theme="light"] .report-section { background: #fff !important; background-image: none !important; color: #000 !important; }
            .report *,
            .report-section *,
            .section * { color: #000 !important; }
            html[data-theme="dark"] .report *,
            html[data-theme="dark"] .report-section *,
            html[data-theme="dark"] .section * { color: #000 !important; }
            html[data-theme="light"] .report *,
            html[data-theme="light"] .report-section *,
            html[data-theme="light"] .section * { color: #000 !important; }
            .report h1,
            .report h2,
            .report h3,
            .report h4,
            .report strong,
            .report-section h1,
            .report-section h2,
            .report-section h3,
            .report-section h4,
            .report-section strong,
            .section h1,
            .section h2,
            .section h3,
            .section h4 { color: #0b4f8a !important; }
            html[data-theme="dark"] .report h1,
            html[data-theme="dark"] .report h2,
            html[data-theme="dark"] .report h3,
            html[data-theme="dark"] .report h4,
            html[data-theme="dark"] .report strong,
            html[data-theme="dark"] .report-section h1,
            html[data-theme="dark"] .report-section h2,
            html[data-theme="dark"] .report-section h3,
            html[data-theme="dark"] .report-section h4,
            html[data-theme="dark"] .report-section strong,
            html[data-theme="dark"] .section h1,
            html[data-theme="dark"] .section h2,
            html[data-theme="dark"] .section h3,
            html[data-theme="dark"] .section h4 { color: #0b4f8a !important; }
            html[data-theme="light"] .report h1,
            html[data-theme="light"] .report h2,
            html[data-theme="light"] .report h3,
            html[data-theme="light"] .report h4,
            html[data-theme="light"] .report strong,
            html[data-theme="light"] .report-section h1,
            html[data-theme="light"] .report-section h2,
            html[data-theme="light"] .report-section h3,
            html[data-theme="light"] .report-section h4,
            html[data-theme="light"] .report-section strong,
            html[data-theme="light"] .section h1,
            html[data-theme="light"] .section h2,
            html[data-theme="light"] .section h3,
            html[data-theme="light"] .section h4 { color: #0b4f8a !important; }
            .report,
            .report-section { border-left: 4px solid #0b4f8a !important; }
            html[data-theme="dark"] .report,
            html[data-theme="dark"] .report-section { border-left: 4px solid #0b4f8a !important; }
            html[data-theme="light"] .report,
            html[data-theme="light"] .report-section { border-left: 4px solid #0b4f8a !important; }
            .score-bar { background: #ddd !important; border: 1px solid #999 !important; }
            html[data-theme="dark"] .score-bar { background: #ddd !important; border: 1px solid #999 !important; }
            html[data-theme="light"] .score-bar { background: #ddd !important; border: 1px solid #999 !important; }
            .score-fill { background: #555 !important; background-image: none !important; }
            html[data-theme="dark"] .score-fill { background: #555 !important; background-image: none !important; }
            html[data-theme="light"] .score-fill { background: #555 !important; background-image: none !important; }
            .alert { background: #fff !important; color: #000 !important; border: 1px solid #999 !important; }
            html[data-theme="dark"] .alert { background: #fff !important; color: #000 !important; border: 1px solid #999 !important; }
            html[data-theme="light"] .alert { background: #fff !important; color: #000 !important; border: 1px solid #999 !important; }
            img { max-width: 100% !important; }
            html[data-theme="dark"] .report em, html[data-theme="dark"] .report i,
            html[data-theme="dark"] .report-section em, html[data-theme="dark"] .report-section i,
            html[data-theme="light"] .report em, html[data-theme="light"] .report i,
            html[data-theme="light"] .report-section em, html[data-theme="light"] .report-section i,
            .report em, .report i, .report-section em, .report-section i { color: #000 !important; }
            :root, html[data-theme="dark"], html[data-theme="light"] { background: #fff !important; color: #000 !important; }
            html[data-theme="dark"] body, html[data-theme="light"] body { background: #fff !important; color: #000 !important; }

        }
"""


def add_darkfix(s):
    if MARK in s:
        return s, 'already'
    if '</style>' not in s:
        return s, 'no style'
    return s.replace('</style>', CSS + '    </style>', 1), 'ok'


def add_printfix(s):
    if PRINT_MARK in s:
        return s, 'already'
    if '</style>' not in s:
        return s, 'no style'
    return s.replace('</style>', PRINT_CSS + '    </style>', 1), 'ok'


if __name__ == '__main__':
    for f in sys.argv[1:]:
        s = open(f, encoding='utf-8').read()
        s2, st = add_darkfix(s)
        s2, st2 = add_printfix(s2)
        if 'ok' in (st, st2):
            open(f, 'w', encoding='utf-8').write(s2)
        print(f.split('/')[-1][:50], 'dark:', st, 'print:', st2)
